# $pattern = "WVDSHW10-"
$pcs = (Get-ADComputer -Filter {name -like '*WVDSHW10-*'}).name
$hostname = hostname

$errors = @()
$counter = 0

foreach ($pcName in $pcs) {
    $counter ++
    Write-Host "Processing $($pcName). Number $($counter) from $($pcs.count)"
    if ($pcName -ne $hostname) {
        $session = New-PSSession -ComputerName $pcName
        try {
            Invoke-Command -ComputerName $pcName -ScriptBlock {Get-ChildItem C:\test}
            # Copy-Item -ToSession $session -Path C:\test\TaxonomyFinal.csv -Destination C:\Scripts\ -Force -ErrorAction Stop
            # Copy-Item -ToSession $session -Path C:\Scripts\TaxonomyFinal.csv -Destination C:\Scripts\ -Force -ErrorAction Stop
            <#Enter-PSSession -Session $session
            Rename-Item -Path C:\Scripts\CreateUser.ps1 -NewName C:\Scripts\CreateUser_old.ps1
            Exit-PSSession#>
        }
        catch {
            Write-Host "$($pcName) can't be processed" -ForegroundColor Red
            # $errors += $pcName
            $errors += $_
        }
        # Invoke-Command -SessionName $session -ScriptBlock { Get-ChildItem "c:\print" }
    }
}

<#
for ($i = 0; $i -le 10; $i++) {
    $pcName = $pattern + $i
    Write-Host "$pcName"    
    if ($pcName -ne $hostname) {
        $session = New-PSSession -ComputerName $pcName
        # Copy-Item -ToSession $session -Path C:\Scripts\TaxonomyFinal.csv -Destination C:\Scripts\ -Force
        Invoke-Command -SessionName $session -ScriptBlock { Get-ChildItem "c:\print" }
    }
    
}

#>