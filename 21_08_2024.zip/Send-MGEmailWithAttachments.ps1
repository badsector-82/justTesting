$MailSender = "martin.gospodinov@apexgroup.com"
$Recipient = "martin.gospodinov@apexgroup.com"

$b = Connect-AzAccount -Identity
$token = Get-AzAccessToken -ResourceUrl "https://graph.microsoft.com"
$a = Connect-MgGraph -AccessToken ($token.Token | ConvertTo-SecureString -AsPlainText -Force)

$stAccount = Get-AzStorageAccount -ResourceGroupName 'FundrockBusinessSupportReports' -Name 'sometestaccounthere1'
$storageContext = New-AzStorageContext -StorageAccountName $stAccount.StorageAccountName -UseConnectedAccount
Get-AzStorageBlobContent -Container 'reports' -Blob 'Internal.csv' -Context $storageContext -Destination "$env:TEMP\internal_1.csv"
Get-AzStorageBlobContent -Container 'reports' -Blob 'External.csv' -Context $storageContext -Destination "$env:TEMP\external_1.csv"

$attInternal = "$env:TEMP\internal_1.csv"
$attExternal = "$env:TEMP\external_1.csv"

$FileNameInternal = (Get-Item -Path $attInternal).name
$FileNameExternal = (Get-Item -Path $attExternal).name

$base64stringInternal = [Convert]::ToBase64String([IO.File]::ReadAllBytes($attInternal))
$base64stringExternal = [Convert]::ToBase64String([IO.File]::ReadAllBytes($attExternal))

$URLsend = "https://graph.microsoft.com/v1.0/users/$MailSender/sendMail"
$BodyJsonsend = @"
                    {
                        "message": {
                          "subject": "Hello World from Microsoft Graph API",
                          "body": {
                            "contentType": "HTML",
                            "content": "This Mail is sent via Microsoft <br>
                            GRAPH <br>
                            API<br>
                            and an Attachment <br>
                            "
                          },
                          
                          "toRecipients": [
                            {
                              "emailAddress": {
                                "address": "$Recipient"
                              }
                            }
                          ]
                          ,"attachments": [
                            {
                              "@odata.type": "#microsoft.graph.fileAttachment",
                              "name": "$FileNameInternal",
                              "contentType": "text/plain",
                              "contentBytes": "$base64stringInternal"
                            },
                            {
                              "@odata.type": "#microsoft.graph.fileAttachment",
                              "name": "$FileNameExternal",
                              "contentType": "text/plain",
                              "contentBytes": "$base64stringExternal"
                            }
                          ]
                        },
                        "saveToSentItems": "true"
                      }
"@

# Invoke-RestMethod -Method POST -Uri $URLsend -Headers $headers -Body $BodyJsonsend

Send-MgUserMail -UserId $MailSender -BodyParameter $BodyJsonsend

<#better use this:
$params = @{
    Message         = @{
        Subject       = $subject
        Body          = @{
            ContentType = $type
            Content     = $body
        }
        ToRecipients  = @(
            @{
                EmailAddress = @{
                    Address = $recipient
                }
            }
        )
        CcRecipients  = @(
            @{
                EmailAddress = @{
                    Address = $ccrecipient
                }
            }
        )
        BccRecipients = @(
            @{
                EmailAddress = @{
                    Address = $bccrecipient
                }
            }
        )
        Attachments   = @(
            @{
                "@odata.type" = "#microsoft.graph.fileAttachment"
                Name          = $attachmentname
                ContentType   = "text/plain"
                ContentBytes  = $attachmentmessage
            }
        )
    }
    SaveToSentItems = $save
}
#>