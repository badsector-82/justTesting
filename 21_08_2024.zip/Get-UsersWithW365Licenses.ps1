$allUsers = Get-ADUser -Filter { enabled -eq $true } -Server apexgroup.cloud -Properties memberOf
[system.collections.arraylist]$members = @()
foreach ($user in $allUsers) {
    $memberships = $user | select -ExpandProperty memberOf
    foreach ($item in $memberships) {
        if ($item -like "*G_Sec_CLOUD_License_Win365*") {
            $object = [PSCustomObject][ordered]@{
                User  = $user.Name
                UserPrincipalName = $user.UserPrincipalName
                Group = $item
            }
            [void]$members.Add($object)
        } 
    }
}
