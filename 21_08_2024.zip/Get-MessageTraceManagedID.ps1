$a = Connect-ExchangeOnline -ManagedIdentity -Organization 'apexfs.onmicrosoft.com'
Connect-AzAccount -Identity -accountID '8f7973c4-c47b-4b0d-a2a1-1f71f1fe342e'

$errors = @()

$wholeTrace = Get-MessageTrace -StartDate ((Get-Date).AddDays(-10)) -EndDate (Get-Date) -SenderAddress 'businesssupport@fundrock.com'

$internal = @()
$external = @()

foreach ($trace in $wholeTrace[30..99]) {
    $detail = $trace | Get-MessageTraceDetail
    if ($detail.Event -contains "Send External") {
        $external += $trace
    }
    else {
        $internal += $trace
    }
}

$internal | select Received, SenderAddress, RecipientAddress, Subject, Status | Export-Csv "$env:TEMP\internal_1.csv" -NoTypeInformation
$external | select Received, SenderAddress, RecipientAddress, Subject, Status | Export-Csv "$env:TEMP\external_1.csv" -NoTypeInformation

$stAccount = Get-AzStorageAccount -ResourceGroupName 'FundrockBusinessSupportReports' -Name 'sometestaccounthere1'
$storageContext = New-AzStorageContext -StorageAccountName $stAccount.StorageAccountName -UseConnectedAccount

# Set-AzStorageBlobContent -BlobType Append -Container 'reports' -Blob 'Internal.csv' -Context $storageContext -File "$env:TEMP\internal_1.csv" -Force
# Set-AzStorageBlobContent -BlobType Append -Container 'reports' -Blob 'External.csv' -Context $storageContext -File "$env:TEMP\external_1.csv" -Force
<#
$stAccount = Get-AzStorageAccount -ResourceGroupName 'FundrockBusinessSupportReports' -Name 'sometestaccounthere1'
$storageContext = New-AzStorageContext -StorageAccountName $stAccount.StorageAccountName -UseConnectedAccount
$container = New-AzStorageContainer -Name 'reports' -Context $storageContext
$container
#>
$container = (Get-AzStorageContainer -Name 'reports' -Context $storageContext).CloudBlobContainer

$encoding = [System.Text.Encoding]::UTF8
$blobInternal = Get-AzStorageBlob -Container 'reports' -Blob 'Internal.csv' -Context $storageContext
$contentToAddInternal = [System.IO.File]::OpenRead("$env:TEMP\internal_1.csv")
$blobInternal.BlobBaseClient.AppendBlock($contentToAddInternal)
$contentToAddInternal.Close()

$blobExternal = Get-AzStorageBlob -Container 'reports' -Blob 'External.csv' -Context $storageContext
$contentToAddExternal = [System.IO.File]::OpenRead("$env:TEMP\external_1.csv")
$blobExternal.BlobBaseClient.AppendBlock($contentToAddExternal)
$contentToAddExternal.Close()
