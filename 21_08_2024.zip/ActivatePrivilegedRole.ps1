# $group = Get-AzureADMSPrivilegedResource -ProviderId aadGroups -Filter "displayName eq 'Sec_SG_PIM_Apex_System_Admin_L3'"
# $user = Get-AzureADUser -ObjectId admin_martin1_esae@apexgroup.global
<# Get-AzureADMSPrivilegedResource -ProviderId aadGroups -Filter "displayName eq 'Sec_SG_PIM_Apex_System_Admin_L3'"
Get-AzureADMSPrivilegedRoleDefinition -ProviderId aadGroups -ResourceId $group.id -Id eb264556-fcc3-4342-b5d6-86fec8c80b44
Get-AzureADMSPrivilegedRoleAssignment -ProviderId aadGroups -ResourceId $group.id -Filter "ResourceId eq '$groupId' and AssignmentState eq 'Eligible'"
Get-AzureADMSPrivilegedRoleAssignment -ProviderId aadGroups -ResourceId $group.id -Filter "ResourceId eq '$groupId' and SubjectId eq '$userID'"
$role = Get-AzureADMSPrivilegedRoleDefinition -ProviderId aadGroups -ResourceId $group.id -Id eb264556-fcc3-4342-b5d6-86fec8c80b44 #>
try {
    Get-AzureADUser -SearchString martin.gospodinov@apexgroup.com -ErrorAction Stop
}
catch {
    Connect-AzureAD
}
Import-Module AzureADPreview -Force
$groupID = '56c070ab-c6d4-4d4b-b8ea-1e3328b8cacd'
$roleID = 'eb264556-fcc3-4342-b5d6-86fec8c80b44'
$userID = '0db8f17a-b176-462b-82be-97cd44e67847'
$reason = "Desperately need to do thousands of tickets!"

$schedule = New-Object Microsoft.Open.MSGraph.Model.AzureADMSPrivilegedSchedule
$schedule.Type = "Once"
$schedule.StartDateTime = Get-Date
$schedule.endDateTime = (Get-date).AddHours(2)
$props = @{
    ProviderId       = 'aadGroups'
    ResourceId       = $groupID
    RoleDefinitionId = $roleID
    SubjectId        = $userID
    AssignmentState  = 'Active'
    Type             = 'UserAdd'
    Schedule         = $schedule
    Reason           = $reason
}

Open-AzureADMSPrivilegedRoleAssignmentRequest @props
#$MsResponse = Get-MSALToken -Scopes @("https://graph.microsoft.com/.default") -ClientId "1b730954-1685-4b74-9bfd-dac224a7b894" -RedirectUri "urn:ietf:wg:oauth:2.0:oob" -Authority "https://login.microsoftonline.com/common" -Interactive -ExtraQueryParameters @{claims='{"access_token" : {"amr": { "values": ["mfa"] }}}'}
#$AadResponse = Get-MSALToken -Scopes @("https://graph.windows.net/.default") -ClientId "1b730954-1685-4b74-9bfd-dac224a7b894" -RedirectUri "urn:ietf:wg:oauth:2.0:oob" -Authority "https://login.microsoftonline.com/common"