Connect-AzAccount -Identity
Set-AzContext -Subscription "Microsoft Azure"
$workspaceName = "ApexO365Logsworkspace"
$workspaceRG = "ApexRSG"
$WorkspaceID = (Get-AzOperationalInsightsWorkspace -Name $workspaceName -ResourceGroupName $workspaceRG).CustomerID

$results = @()
# $recent = Get-AzureADUser -SearchString 'martin.gospodinov@apexgroup.com'

# $disabledUsers = Get-AzureADUser -Filter "AccountEnabled eq false" -All $true
$disabledUsers = Get-MgBetaUser -Filter "AccountEnabled eq false" -All
# $recent = $disabledUsers | ? { $_.LastDirSyncTime -gt ((Get-Date).AddDays(-30)) }
$recent = $disabledUsers | ? { $_.OnPremisesLastSyncDateTime -gt ((Get-Date).AddDays(-30)) }

Measure-Command {
    foreach ($user in $recent) {
        # $disableDate = $user.LastDirSyncTime
        $disableDate = $user.OnPremisesLastSyncDateTime
        $query = "SigninLogs
| where TimeGenerated > datetime('$($disableDate)') and UserPrincipalName == '$($user.UserPrincipalName)'
| project UserPrincipalName, Status, ClientAppUsed, TimeGenerated, AppDisplayName, AppId, Location, DeviceDetail, IsInteractive, IPAddress, LocationDetails, NetworkLocationDetails"
        $kqlQuery = Invoke-AzOperationalInsightsQuery -WorkspaceId $WorkspaceID -Query $query
        $results += $kqlQuery.Results
    }
}

$date = Get-Date -Format 'dd-MM-yyyy'
$results | Export-Csv "$env:TEMP\results_$date.csv"

<#
1. Create automation account with the following parameters:
 - Subscription = Microsoft Azure
 - Resource group = ApexRSG
 - Automation account name = aaacc-prod-eunorth-001
 - Managed Identities = System Assigned
2. Log Analytics Workspace - ApexO365Logsworkspace - give Reader permissions to the automation account's managed identity
 - Add role assignment = Reader
 - Members = Automation account's managed identity
3. Graph permissions for the automation account's managed identity:
 - Exchange.ManageAsApp
 - User.Read.All
 - Mail.Send
 - Mail.ReadWrite
4. Exchange Online
 - create shared mailbox for sending the reports - DisabledAccountsSigninReports@apexgroup.com
5. Exchange Online - Limit automation account permissions only to the shared mailbox through RBAC:
 - Create a service principal in ExO for the automation account's managed identity
 - Create a new managements scope, restricting access only to the shared mailbox
 - Assign the management scope to the service principal with role "Application Mail.Send"
6. Automation account
 - create a runbook = DisabledUsersSigninAttempts
 - runbook type = powershell
 - version = 7.2
 - import code into workbook. File with code is attached to the change request
7. Import modules into automation account
 - microsoft.graph.beta
 - Microsoft.Graph.Authentication
 - Microsoft.Graph.Beta.Users
 - Microsoft.Graph.Users.Actions
 - ExchangeOnlineManagement
8. Schedule runbook execution:
 - Name = WeeklyMondayReport
 - occur every week on Monday. No expiration.
#>