$toDelete = gc C:\test\toDelete_16.txt
$exceptions = gc C:\test\exceptions_5.txt

$server = "VMADS003.APEXGROUP.CLOUD"

$counter = 0
$errorsQueringUsers = @()
$errorsRemovingMemberships = @()
$membershipsRemoved = @()
$exceptionsFinal = @()

foreach ($user in $toDelete) {
    $counter++
    if ($counter % 10 -eq '0') {
        Write-Host "Processing user $($counter) from $($toDelete.count)" -ForegroundColor Green
    }
    try {
        $queriedUser = Get-ADUser -Filter { UserPrincipalName -eq $user } -Properties memberOf -Server $server -ErrorAction Stop
    }
    catch {
        $errorQueringUsers = [PSCustomObject] @{
            Error        = $_
            ErrorCommand = $error[0]
            Username     = $user
            Counter      = $counter
        }
        $errorsQueringUsers += $errorQueringUsers
    }
    if ($exceptions -like "*$user*") {
        Write-Host "User $($user) excepted" -ForegroundColor Red
        $exceptionsFinal += $user
        continue
    }
    $groups = $queriedUser | select -ExpandProperty memberOf
    foreach ($group in $groups) {
        if ($group -like "CN=G_Sec_CTX*") {
            Start-Sleep -Milliseconds 200
            try { 
                Write-Host "Removing group membership for user $($user) and group $($group)"               
                Remove-ADGroupMember -Identity $group -Members $queriedUser.SamAccountName -Server $server -Confirm:$false
                $removedMembership = [PSCustomObject] @{
                    Group = $group
                    User  = $user
                }
                $membershipsRemoved += $removedMembership
            }
            catch {
                $errorRemovingMembership = [PSCustomObject]@{
                    Error        = $_
                    ErrorCommand = $error[0]
                    Group        = $group
                    User         = $user
                }
                $errorsRemovingMemberships += $errorRemovingMembership
            }
            $errorsRemovingMemberships += $user
        }
    }
}
$secondChance = @()
foreach ($user in $unsuccessful) {
    $a = Get-ADUser -Filter {userPrincipalName -eq $user} -Properties memberOf -Server apexgroup.CLOUD
    foreach ($group in $a.memberOf) {
        if ($group -like '*G_Sec_CTX*') {
            $secondChance += $user
        }
    }
}