#=======================================================================================
#region Office 365 - PowerShell Command Center Documentation
#=======================================================================================

<# ----------Microsoft Interanl Only----------
Title: PowerShell Command Center
Version: 2
Date: 5.23.2019
Authors: Paul Kotylo (paul.kotylo@microsoft.com)
----------Microsoft Interanl Only---------- #>

#endregion
#=======================================================================================

#=======================================================================================
#region POWERSHELL Assembly
#=======================================================================================

Add-Type -AssemblyName System.Windows.Forms | Out-Null
Add-Type -AssemblyName System.Drawing | Out-Null

#endregion
#=======================================================================================

#=======================================================================================
#region FUNCTIONS
#=======================================================================================
function HelperData($WindowTitle, $Info, $Url)
{
    $txtOpenURL.Text = $Url
    $txtDocumentationHelperWindow_Title.Text = $WindowTitle
    $txtDocumentationHelperWindow_Info.Text = $Info
    $btnDocumentationHelperWindow_GenerateInputFile.IsEnabled = $false
    $gridDocumentationHelperWindow.visibility = "Visible"
}

Function UnblockFiles()
{
    $PsccName = $script:MyInvocation.MyCommand.Name
    $PSCCRoot = $script:MyInvocation.MyCommand.Source -replace "$PsccName",""
    $PSCCScript = $script:MyInvocation.MyCommand.Source
    Get-Item $PSCCScript | Unblock-File
    Get-ChildItem $PSCCRoot`Modules -Recurse | Unblock-File
}
Function New-ThreadMonitor
{
    [void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework') 
    $Global:syncHash              = [hashtable]::Synchronized(@{})
    $newRunspace                  = [runspacefactory]::CreateRunspace()
    $Global:syncHash.Runspace     = $newRunspace
    $Global:syncHash.WindowHeight = 0
    $Global:syncHash.Hash         = $global:construct
    $newRunspace.ApartmentState   = "STA" 
    $newRunspace.ThreadOptions    = "ReuseThread"           
    $data                         = $newRunspace.Open() | Out-Null
    $newRunspace.SessionStateProxy.SetVariable("syncHash",$syncHash)
    $PowerShellCommand            = [PowerShell]::Create().AddScript(
    {
        [string]$Global:xaml2         = @"
        <Window 
            xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation" 
            xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml" 
            Name="RunspaceWindow" Title="PowerShell Command Center Thread Monitor" WindowStartupLocation = "CenterScreen" 
            Width = "570" Height="50" ShowInTaskbar = "True">
            <Grid Name="gridConfigWindow" HorizontalAlignment="Left"  Height="502" Margin="47,10,0,0" VerticalAlignment="Top" Width="468">
                <Grid Name="gridConfigWindow2" HorizontalAlignment="Left"  Height="502" Margin="-3,3,0,-3" VerticalAlignment="Top" Width="471">
                    <TextBlock Name="TenantInfo" Text="TenantInfo" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="4,2,1,480" Width="466" TextWrapping="Wrap" FontSize="16" />
                    <TextBlock Name="ScriptInfo" Text="ScriptInfo" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="14,25,1,461" Width="456" TextWrapping="Wrap" />
                    <ProgressBar Name="ProgressBar1" Height="20" Margin="3,56,29,426" Visibility="Collapsed"/>
                    <TextBlock Name="pBar1Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,56,33,426" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread1MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,56,-114,426" Height="20" Width="30" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread1" Content="" HorizontalAlignment="Left" Margin="444,56,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar2" Height="20" Margin="3,81,29,401" Visibility="Collapsed"/>
                    <TextBlock Name="pBar2Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,81,33,401" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread2MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,81,-116,401" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread2" Content="" HorizontalAlignment="Left" Margin="444,81,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar3" Height="20" Margin="3,106,29,376" Visibility="Collapsed"/>
                    <TextBlock Name="pBar3Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,106,33,376" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread3MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,106,-116,376" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread3" Content="" HorizontalAlignment="Left" Margin="444,106,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar4" Height="20" Margin="3,131,29,351" Visibility="Collapsed"/>
                    <TextBlock Name="pBar4Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,131,33,351" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread4MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,131,-116,351" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread4" Content="" HorizontalAlignment="Left" Margin="444,131,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar5" Height="20" Margin="3,156,29,326" Visibility="Collapsed"/>
                    <TextBlock Name="pBar5Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,156,33,326" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread5MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,156,-116,326" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread5" Content="" HorizontalAlignment="Left" Margin="444,156,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar6" Height="20" Margin="3,181,29,301" Visibility="Collapsed"/>
                    <TextBlock Name="pBar6Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,181,33,301" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread6MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,181,-116,301" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread6" Content="" HorizontalAlignment="Left" Margin="444,181,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar7" Height="20" Margin="3,206,29,276" Visibility="Collapsed"/>
                    <TextBlock Name="pBar7Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,206,33,276" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread7MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,206,-116,276" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread7" Content="" HorizontalAlignment="Left" Margin="444,206,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar8" Height="20" Margin="3,231,29,251" Visibility="Collapsed"/>
                    <TextBlock Name="pBar8Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,231,33,251" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread8MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,231,-116,251" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread8" Content="" HorizontalAlignment="Left" Margin="444,231,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar9" Height="20" Margin="3,256,29,226" Visibility="Collapsed"/>
                    <TextBlock Name="pBar9Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,256,33,226" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread9MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,256,-116,226" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread9" Content="" HorizontalAlignment="Left" Margin="444,256,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar10" Height="20" Margin="3,281,29,201" Visibility="Collapsed"/>
                    <TextBlock Name="pBar10Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,281,33,201" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread10MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,281,-116,201" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread10" Content="" HorizontalAlignment="Left" Margin="444,281,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar11" Height="20" Margin="3,306,29,176" Visibility="Collapsed"/>
                    <TextBlock Name="pBar11Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,306,33,176" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread11MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,306,-116,176" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread11" Content="" HorizontalAlignment="Left" Margin="444,306,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar12" Height="20" Margin="3,331,29,151" Visibility="Collapsed"/>
                    <TextBlock Name="pBar12Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,331,33,151" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread12MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,331,-116,151" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread12" Content="" HorizontalAlignment="Left" Margin="444,331,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar13" Height="20" Margin="3,356,29,126" Visibility="Collapsed"/>
                    <TextBlock Name="pBar13Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,355,33,127" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread13MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,355,-116,127" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread13" Content="" HorizontalAlignment="Left" Margin="444,355,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar14" Height="20" Margin="3,381,29,101" Visibility="Collapsed"/>
                    <TextBlock Name="pBar14Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,381,33,101" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread14MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,381,-116,101" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread14" Content="" HorizontalAlignment="Left" Margin="444,381,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar15" Height="20" Margin="3,406,29,76" Visibility="Collapsed"/>
                    <TextBlock Name="pBar15Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,406,33,76" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread15MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,406,-116,76" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread15" Content="" HorizontalAlignment="Left" Margin="444,406,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar16" Height="20" Margin="3,431,29,51" Visibility="Collapsed"/>
                    <TextBlock Name="pBar16Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,431,33,51" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread16MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,431,-116,51" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread16" Content="" HorizontalAlignment="Left" Margin="444,431,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar17" Height="20" Margin="3,456,29,26" Visibility="Collapsed"/>
                    <TextBlock Name="pBar17Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,456,33,26" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread17MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,456,-116,26" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread17" Content="" HorizontalAlignment="Left" Margin="444,456,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar18" Height="20" Margin="3,481,29,1" Visibility="Collapsed"/>
                    <TextBlock Name="pBar18Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,481,33,1" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread18MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,481,-116,1" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread18" Content="" HorizontalAlignment="Left" Margin="444,481,0,0" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar19" Height="20" Margin="3,506,29,-24" Visibility="Collapsed"/>
                    <TextBlock Name="pBar19Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,506,33,-24" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread19MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,506,-116,-24" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread19" Content="" HorizontalAlignment="Left" Margin="444,506,0,-24" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                    <ProgressBar Name="ProgressBar20" Height="20" Margin="3,531,29,-49" Visibility="Collapsed"/>
                    <TextBlock Name="pBar20Status" Text="Status" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="6,531,33,-49" Height="20" Width="432" FontFamily="Segoe UI Light" Visibility="Collapsed"/>
                    <TextBlock Name="Thread20MWH" Text="null" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="552,531,-116,-49" Height="20" Width="32" FontFamily="Segoe UI Light" Visibility="Collapsed" RenderTransformOrigin="0.5,0.5"/>
                    <Button Name="HideShowThread20" Content="" HorizontalAlignment="Left" Margin="444,531,0,-49" VerticalAlignment="Top" Width="24" FontFamily="Webdings" Height="20" Visibility="Collapsed"/>
                </Grid>
            </Grid>
        </Window>
"@ 
        $Global:syncHash.RunspaceWindow=[Windows.Markup.XamlReader]::parse( $global:xaml2 ) 
        ([xml]$global:xaml2).SelectNodes("//*[@Name]") | %{ $Global:syncHash."$($_.Name)" = $Global:syncHash.RunspaceWindow.FindName($_.Name)}
        $updateBlock = `
        {    
            $Global:syncHash.AdditionalInfoTextBlock.Text = $Global:syncHash.AdditionalInfo
            $Global:syncHash.RunspaceWindow.Height = $Global:syncHash.WindowHeight
            $ProcessCount = $Global:syncHash.Count
            $Global:syncHash.TenantInfo.Text = $Global:syncHash.TenantInfoText
            $Global:syncHash.ScriptInfo.Text = $Global:syncHash.ScriptInfoText
            for($i=1;$i -le $ProcessCount; $i++)
            {
                $Global:syncHash."pBar$($i)Status".Text = $Global:syncHash."StatusPbar$($i)"
                $Global:syncHash."pBar$($i)Status".Visibility = $Global:syncHash."StatusPbar$($i)Visibility"
                $Global:syncHash."ProgressBar$($i)".Value = $Global:syncHash."PercentCompletePbar$($i)"
                $Global:syncHash."ProgressBar$($i)".Visibility = $Global:syncHash."PercentCompletePbar$($i)visibility"
                $Global:syncHash."HideShowThread$($i)".Visibility = $Global:syncHash."HideShowThread$($i)visibility"
                $Global:syncHash."Thread$($i)MWH".Text = $Global:syncHash."PSThread$($i)MWH"         
            }
        }
        $Global:syncHash.HideShowThread1.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread1MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread2.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread2MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread3.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread3MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread4.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread4MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread5.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread5MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread6.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread6MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread7.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread7MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread8.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread8MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread9.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread9MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread10.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread10MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread11.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread11MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread12.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread12MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread13.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread13MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread14.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread14MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread15.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread15MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread16.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread16MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread17.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread17MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread18.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread18MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread19.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread19MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })
        $Global:syncHash.HideShowThread20.Add_click(
        {
            $ProcID        = $Global:syncHash."Thread20MWH".Text
            $hWnd          = [System.IntPtr][Int]$ProcID
            $type1          = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern bool ShowWindowAsync(IntPtr hWnd, int nCmdShow);' -Name "Name" -PassThru
            $type1::ShowWindowAsync($hWnd, 10)
            $type1::ShowWindowAsync($hWnd, 4)
            $type1::ShowWindowAsync($hWnd, 5)
            $type2 = Add-Type -MemberDefinition '[DllImport("user32.dll")] public static extern int SetForegroundWindow(IntPtr hwnd);' -Name WindowAPI -PassThru
            $type2::SetForegroundWindow($hwnd) 
        })

        $Global:syncHash.RunspaceWindow.Add_SourceInitialized(
        {            
            $RunspaceTimer          = new-object System.Windows.Threading.DispatcherTimer
            $RunspaceTimer.Interval = [TimeSpan]"0:0:1"
            $RunspaceTimer.Add_Tick( $updateBlock )
            $RunspaceTimer.Start()
        })
        $Global:syncHash.RunspaceWindow.ShowDialog() | Out-Null 
        $Global:syncHash.Error     = $Error 
    })
    $PowerShellCommand.Runspace = $newRunspace 
    $data                       = $PowerShellCommand.BeginInvoke() 
    Register-ObjectEvent -InputObject $Global:syncHash.Runspace `
            -EventName 'AvailabilityChanged' `
            -Action `
            {
                if($Sender.RunspaceAvailability -eq "Available")
                {
                    $Sender.Closeasync()
                    $Sender.Dispose()
                }
            } | Out-Null
    return $Global:syncHash
    } 

function Write-ThreadMonitor($ProgressBar,$Processes,$TenantInfoText,$ScriptInfoText,$WindowHeight)
{
    $ProcessCount                                                  = ($Processes | Measure-Object).Count
    $ProgressBar.Count                                             = $ProcessCount
    for($i=1;$i -le $ProcessCount; $i++)
    {
        $ProcessTitle                                              = $Processes[$i - 1].MainWindowTitle
        $ThreadNumber                                              = $Processes[$i - 1].ThreadNumber
        $Line                                                      = ($Processes[$i - 1].MainWindowTitle -split "\| ")[3]
        [double]$PercentComplete                                   = (($Processes[$i - 1].MainWindowTitle -split "\| ")[4] -split " ")[1] -replace "%"
        $MWH                                                       = $Processes[$i - 1].MainWindowHandle
        $Status                                                    = $Processes[$i - 1].Status
        $CompletedStatus                                           = $Processes[$i - 1].HasCompleted
        if($Status -eq "Found")
        {
            if(($ProcessTitle -like "*| Percent: *") -and ($ProcessTitle -notlike "* | Complete"))
            {
                [datetime]$StartTime                               = $Processes[$i - 1].StartTime
                $SecondsElapsed                                    = ([datetime]::Now - $StartTime)
                $SecondsRemaining                                  = ($SecondsElapsed.TotalSeconds / ($PercentComplete / 100)) - $SecondsElapsed.TotalSeconds
                $infinite                                          = 1.1/0
                if($SecondsRemaining -ne $infinite)
                {
                    $TimeRemaining =  [timespan]::fromseconds($SecondsRemaining)
                }
                $TimeRemainingDays                                 = $TimeRemaining.Days 
                $TimeRemainingHours                                = $TimeRemaining.Hours 
                $TimeRemainingMinutes                              = $TimeRemaining.Minutes 
                $TimeRemainingSeconds                              = $TimeRemaining.Seconds 
                if($TimeRemainingDays)
                {
                    $RemainingTime              = "$TimeRemainingDays`d:$TimeRemainingHours`h:$TimeRemainingMinutes`m:$TimeRemainingSeconds`s"
                }
                elseif($TimeRemainingHours)
                {
                    $RemainingTime         = "$TimeRemainingHours`h:$TimeRemainingMinutes`m:$TimeRemainingSeconds`s"
                }
                elseif($TimeRemainingMinutes)
                {
                    $RemainingTime       = "$TimeRemainingMinutes`m:$TimeRemainingSeconds`s"
                }
                elseif($TimeRemainingSeconds)
                {
                    $RemainingTime       = "$TimeRemainingSeconds`s"}
                $StatusLine                                        = "Thread: $ThreadNumber | $Line | $PercentComplete% | $RemainingTime"
            }
            elseif($ProcessTitle -like "* | Complete")
            {
                $StatusLine = "Thread: $ThreadNumber | $Line | $PercentComplete% | Complete"
            }
            Else
            {
                $StatusLine                                       = "Thread: $ThreadNumber | Initializing..."
            }
            $ProgressBar."PercentCompletePbar$($i)"                = $PercentComplete
            $ProgressBar."StatusPbar$($i)"                         = $StatusLine
        }
        elseif($Status -eq "NotFound")
        {
            if($CompletedStatus -eq $true)
            {
                $StatusLine                                        = "Thread: $ThreadNumber | 100% | Thread Closed."
                $ProgressBar."PercentCompletePbar$($i)"            = 100
                $ProgressBar."StatusPbar$($i)"                     = $StatusLine
            }
            else
            {
                $StatusLine                                        = "Thread: $ThreadNumber | Thread unresolvable."
                $ProgressBar."PercentCompletePbar$($i)"            = 0
                $ProgressBar."StatusPbar$($i)"                     = $StatusLine
            }
        }
        $ProgressBar."PercentCompletePbar$($i)visibility"          = "Visible"
        $ProgressBar."StatusPbar$($i)visibility"                   = "Visible"
        $ProgressBar."HideShowThread$($i)visibility"               = "Visible"
        $ProgressBar."PSThread$($i)MWH"                            = $MWH
    }
    $ProgressBar.TenantInfoText                                    = $TenantInfoText
    $ProgressBar.ScriptInfoText                                    = $ScriptInfoText
    $ProgressBar.WindowHeight                                      = $WindowHeight
}

Function New-ProgressBar 
{
    [void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework') 
    $Global:syncHash                = [hashtable]::Synchronized(@{})
    $newRunspace                    = [runspacefactory]::CreateRunspace()
    $Global:syncHash.Runspace       = $newRunspace
    $Global:syncHash.AdditionalInfo = ''
    $newRunspace.ApartmentState     = "STA" 
    $newRunspace.ThreadOptions      = "ReuseThread"           
    $data                           = $newRunspace.Open() | Out-Null
    $newRunspace.SessionStateProxy.SetVariable("syncHash",$syncHash)
    $PowerShellCommand              = [PowerShell]::Create().AddScript(
    {  
        [string]$Global:xaml2       = @"
        <Window
            xmlns="http://schemas.microsoft.com/winfx/2006/xaml/presentation"
            xmlns:x="http://schemas.microsoft.com/winfx/2006/xaml"
            xmlns:d="http://schemas.microsoft.com/expression/blend/2008"
            xmlns:mc="http://schemas.openxmlformats.org/markup-compatibility/2006" 
            x:Name="RunspaceWindow"
            Title="PowerShell Command Center 365 v0.2.4" Height="186.666" Width="400.667"
            WindowStyle="None" AllowsTransparency="True"
            Background="Transparent" WindowStartupLocation="CenterScreen">
            <Grid x:Name="gridRunspaceWindow" HorizontalAlignment="Left"  Height="187" VerticalAlignment="Top" Width="401" Visibility="Visible">
                <Rectangle Name="rectgridRunspaceWindow_Body" HorizontalAlignment="Left" Height="116" VerticalAlignment="Top" Width="379" Stroke="Black" Fill="#FFF1F9FF" IsEnabled="False" Margin="10,36,0,0"/>
                <ProgressBar Name="ProgressBar" HorizontalAlignment="Right" Width="337" Margin="0,56,32,115" />
                <TextBlock Text="{Binding ElementName=ProgressBar, Path=Value, StringFormat={}{0:0}%}" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="32,56,32,115" Width="337" FontFamily="Segoe UI Light" TextAlignment="Center" />
                <TextBlock Name="AdditionalInfoTextBlock" Text="" HorizontalAlignment="Center" VerticalAlignment="Center" Margin="21,76,22,47" Width="358" Height="64" TextAlignment="Center" FontFamily="Segoe UI Light" TextWrapping="Wrap" />
            </Grid>
        </Window> 
"@ 
        $Global:syncHash.RunspaceWindow=[Windows.Markup.XamlReader]::parse( $global:xaml2 ) 
        ([xml]$global:xaml2).SelectNodes("//*[@Name]") | %{ $Global:syncHash."$($_.Name)" = $Global:syncHash.RunspaceWindow.FindName($_.Name)}
        $updateBlock = `
        {            
            $Global:syncHash.RunspaceWindow.Title = $Global:syncHash.Activity
            $Global:syncHash.ProgressBar.Value = $Global:syncHash.PercentComplete
            $Global:syncHash.AdditionalInfoTextBlock.Text = $Global:syncHash.AdditionalInfo
        }
        $Global:syncHash.RunspaceWindow.Add_SourceInitialized(
        {            
            $RunspaceTimer          = new-object System.Windows.Threading.DispatcherTimer
            $RunspaceTimer.Interval = [TimeSpan]"0:0:0.01"
            $RunspaceTimer.Add_Tick($updateBlock)
            $RunspaceTimer.Start()
        })
        $Global:syncHash.RunspaceWindow.ShowDialog() | Out-Null 
        $Global:syncHash.Error     = $Error 
    })
    $PowerShellCommand.Runspace = $newRunspace 
    $data                       = $PowerShellCommand.BeginInvoke() 
    Register-ObjectEvent -InputObject $Global:syncHash.Runspace `
            -EventName 'AvailabilityChanged' `
            -Action `
            {
                if($Sender.RunspaceAvailability -eq "Available")
                {
                    $Sender.Closeasync()
                    $Sender.Dispose()
                }
            } | Out-Null
    return $Global:syncHash
}

function Write-ProgressBar($ProgressBar,[String]$Activity,[int]$PercentComplete,[String]$CurrentOperation)
{
   $ProgressBar.Activity                             = $Activity
   if($PercentComplete)
    {   
       $ProgressBar.PercentComplete = $PercentComplete
    }
   $ProgressBar.AdditionalInfo                       = "$CurrentOperation"
}

function Close-ProgressBar($ProgressBar)
{
    $ProgressBar.RunspaceWindow.Dispatcher.Invoke([action]{$ProgressBar.RunspaceWindow.close()}, "Normal")
}

#----- Function - Connect to Azure AD -----#
Function PSCC-ConnectMSOL($Actor)
{
    #Get-PSSession | Remove-PSSession
    $PassedActor = $Actor
    #$UserCredential         = Get-Credential
    #$SecureString           = $UserCredential.Password 
    #$BSTR                   = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString) 
    #$PlainPassword          = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($BSTR)
    #$txtM365AdminPWD.text = $PlainPassword 
    #$txtM365AdminUN.text  = $UserCredential.UserName
    PSCC-Refresh -Actor $PassedActor
    $btnConfigWindow_Save.IsEnabled      = $True
}

 #----- Function - Connect to Exchange On-premises -----#
Function PSCC-ConnectExOnPrem
{
    if($txtPSVirtualDirectory.text -eq "")
    {
        $txtPSVirtualDirectory.text    = "Please enter your virtual directory endpoint name"
    }
    if($txtPSVirtualDirectory.text -ne "Please enter your virtual directory endpoint name")
    {
        $UserCredential                = Get-Credential
        $SecureString                  = $UserCredential.Password 
        $SecureStringToBSTR            = [System.Runtime.InteropServices.Marshal]::SecureStringToBSTR($SecureString) 
        $PlainPassword                 = [System.Runtime.InteropServices.Marshal]::PtrToStringAuto($SecureStringToBSTR)
        $txtExOnPremPWD.text           = $PlainPassword 
        $txtExOnPremUNCheck.text       = $UserCredential.UserName
        $txtExOnPremUNCheck.foreground = "Black"
        PSCC-Refresh
    }
}

#----- Function - Refresh O365 Details -----#
Function PSCC-Refresh($Actor)
{
    IF($txtTargetEnvironmentSelection.text -eq "gridM365")
    {
        $Error.Clear()

        if($($txtAppId.Text) -eq "" -or ($($txtAppId.Text) -eq "Disconnected: Authentication Failed"))
        {
            $txtAppId.Text = $txtConfigWindow_NewSave_AppId.Text
            $txtM365Tenant.Text = $txtConfigWindow_NewSave_Name.Text
            $txtAppCertThumbprint.Text = $txtConfigWindow_NewSave_Thumbprint.Text
        }
        $TextBoxTenantName = $txtM365Tenant.Text
        $Thumbprint = $txtAppCertThumbprint.Text
        Connect-AzureAD -ApplicationId $txtAppId.Text -CertificateThumbprint $Thumbprint -TenantId $TextBoxTenantName
        if(!$Error)
        {
            $TenantAADInfo                 = Get-AzureADTenantDetail
            $TenantLong                     = ($TenantAADInfo.VerifiedDomains | where {$_.Initial -eq $true}).Name
            if($TenantLong.count -gt 1)
            {
                $TenantLong                         = $TenantLong[0]
                $TenantShort                        = ($TenantLong.split('.'))[0]
            }
            Else
            {
                $TenantShort                       = ($TenantLong.split('.'))[0]
            }
            $txtConnectionStatus.text       = $txtAppId.Text
            $txtTenantReqs.text             = $TenantShort
            if($Actor -eq "NewConfigWindow")
            {
                $lblTitle.Content = "PowerShell Command Center (Connected to: $TenantShort)"
            }
            else
            {
                $lblTitle.Content                             = "PowerShell Command Center ($($cBoxSelectConfig.SelectedItem) | $TenantShort)"
            }
            $host.ui.rawui.windowtitle           = "PSCC: Host - $($TenantShort)"

            $txtConnectionStatus.foreground = "Green"
            $txtTenantReqs.foreground       = "Green"
            $txtM365Tenant.Text                    = $TenantLong
            if($txtSPOAdminURL.text -eq "https://<tenantname>-admin.sharepoint.com/")
            {
                $txtSPOAdminURL.text = "https://$TenantShort-admin.sharepoint.com/"
                $txtSPOSource.text = $txtSPOAdminURL.text
            }
            if($Actor -eq "btnConfigWindow_Load")
            {
                $gridConfigWindow.Visibility = "Collapsed"
            }
            $CurrentDirectory               = (Resolve-Path .\).Path
            $FullOutputPath                 = "$CurrentDirectory\$TenantShort"
            $ResolveWorkingPath             = Test-Path -Path $FullOutputPath
            if($ResolveWorkingPath -eq $false)
            {
                Write-host "Output directory not found.  Creating output directory."
                mkdir $FullOutputPath
                $ResolveWorkingPath         = Test-Path -Path $FullOutputPath
                $btnOpenTenantRootFolder.Visibility = "Collapsed"
            }
            if($ResolveWorkingPath -eq $True)
            {
                $btnOpenTenantRootFolder.Content = "Open: $TenantShort"
                $btnOpenTenantRootFolder.Visibility = "Visible"
            }
        }
        else
        {
            $TenantLong                         = "Could not locate tenant name.  Please verify credentials"
            $txtConnectionStatus.text           = "Disconnected: Authentication Failed"
            $txtTenantReqs.text                 = "Not conntect to a teant"
            $lblTitle.Content                   = "PowerShell Command Center (Disconnected)"
            $txtConnectionStatus.foreground     = "Red"
            $txtTenantReqs.foreground           = "Red"
            $txtAppId.Text                      = "Disconnected: Authentication Failed"
            $txtAppCertThumbprint.Text          = "Disconnected: Authentication Failed"
            $btnOpenTenantRootFolder.Visibility = "Collapsed"
        }
        if(($Actor -eq "NewConfigWindow") -and ($TenantShort))
        {
            $txtBlockConfigWindow_NewSave_Status.Text = "Connected: $TenantShort"
            $txtSPOAdminURL.text = "https://$TenantShort-admin.sharepoint.com/"
            $txtExOURI.text      = "https://outlook.office365.com/powershell-liveid"
            $txtUIReportingFrequency.Text = 1
            $txtThreshold.Text = 100
            $txtSleep.Text     = 10
            $txtSPOItemExceptions.Text = 1024
            $txtSPOFolderExceptions = 5000
            $txtSPOFileExtensionExceptions.Text = $null
            $txtExOnpremURI.Text = $null
            $checkBoxT2TMigrations.IsChecked = $true
            $txtConfigWindow_NewSave_Name.IsEnabled = $true
            $btnConfigWindow_NewSave_Save.IsEnabled = $true
            $txtM365AdminUN.text = $MSOCapedCred.UserName
            $txtSourceMigUN.text = $null
            $btnConfigWindow_Save.IsEnabled     = $True
            $txtExchangeType.text        = "T2T"
        }
        if(($Actor -eq "NewConfigWindow") -and (!$TenantShort))
        {
            $txtBlockConfigWindow_NewSave_Status.Text = "Disconnected: Invalid Credentials"
            $btnConfigWindow_NewSave_Save.IsEnabled = $False
        }

        <#
    IF($txtTargetEnvironmentSelection.text -eq "gridOnpremises"){
        $Error.Clear()
		#----- Get Domain Controller -----#
        $GlobalCatalogs = (Get-ADForest).GlobalCatalogs
        foreach($GlobalCatalog in $GlobalCatalogs){
            $TCPClient  = New-Object System.Net.Sockets.TcpClient     # Create a new TcpClient object
            $Connect    = $TCPClient.BeginConnect($GlobalCatalog,389,$null,$null)  # Try connecting to port 389 on the DC
            $Connect.AsyncWaitHandle.WaitOne(250,$False) | Out-Null    # Wait 250ms for the connection
            }

            #----- Check DC Connectivity -----#
        if($txtPSVirtualDirectory.text -eq ""){
            $txtPSVirtualDirectory.text = "Please enter your virtual directory endpoint name"
            }
        if($txtPSVirtualDirectory.text -ne "Please enter your virtual directory endpoint name"){
            Get-PSSession | Remove-PSSession
            $Error.Clear()
            $VirDirName        = $txtPSVirtualDirectory.text
            $HTTPvHTTPs        = $lblSSLRequired.content
            $uri               = $HTTPvHTTPs+$VirDirName
            $ExOnPremCapedPWD  = ConvertTo-SecureString -String $txtExOnPremPWD.text -AsPlainText -Force
            $ExOnPremCapedCred = New-Object –TypeName System.Management.Automation.PSCredential –ArgumentList $txtExOnPremUNCheck.text, $ExOnPremCapedPWD
            $Session           = New-PSSession -ConfigurationName Microsoft.Exchange -ConnectionUri $uri/PowerShell/ -Credential $ExOnPremCapedCred -Authentication Kerberos
            if($Error){
                if($Error.Exception.message -like "*The user name or password is incorrect*"){
                    $txtExOnPremUNCheck.foreground     = "Red"
                    $txtExOnPremUNCheck.text           = "Invalid admin credentials"
                    $txtExRemotePSCheck.foreground     = "Red"
                    $txtExRemotePSCheck.text           = "Failed to create session"
                    }
                Else{
                    $txtExOnPremUNCheck.foreground     = "Red"
                    $txtExOnPremUNCheck.text           = "Unknown Failure"
                    $txtExRemotePSCheck.foreground     = "Red"
                    $txtExRemotePSCheck.text           = "Failed to create session"
                    }
                }
            If(!$Error){
                Import-PSSession $Session
                if(!$Error){
                    $txtExOnPremUNCheck.foreground     = "Green"
                    $txtExOnPremUNCheck.text           = $UserCredential.UserName
                    $txtExRemotePSCheck.foreground     = "Green"
                    $txtExRemotePSCheck.text           = "Connection Established"
                    $btnConfigWindow_Save.IsEnabled                 = $True
                    $RSATPreReqCheck=(Get-Module -ListAvailable ActiveDirectory)
                    if($RSATPreReqCheck){
                        Import-Module Activedirectory
                        $OnPremThreadCount             = "8"
                        $cBoxThreads.items.clear()
                        For ($i=1; $i -le $OnPremThreadCount; $i++){$cBoxThreads.items.Add("$i") | Out-Null}
                        $txtADRemotePSCheck.foreground = "Green"
                        $txtADRemotePSCheck.text       = "Connection Established"
                        $txtOnPremOrgConfig.text       = ((Get-ADDomainController).domain)
                        }
                    if(!$RSATPreReqCheck){
                        $txtADRemotePSCheck.foreground = "Red"
                        $txtADRemotePSCheck.text       = "Connection Failed: Need RSAT"
                        }
                    }
                if($Error){
                    $txtExOnPremUNCheck.foreground     = "Red"
                    $txtExOnPremUNCheck.text           = $UserCredential.UserName
                    $txtExRemotePSCheck.foreground     = "Red"
                    $txtExRemotePSCheck.text           = "Failed to import session"
                    }
                }
            }
        }
        #>

    }       
}



#----- Function - Connect to Source (Migrate) -----#
Function PSCC-SourceMigAccount
{
    $SourceMigCred           = Get-Credential
    $txtSourceMigUN.Text     = $SourceMigCred.UserName
    $txtSourceMigPWD.Text    = $SourceMigCred.GetNetworkCredential().Password
}

#----- Function - Get Input File -----#
Function PSCC-InputFile($initialDirectory)
{   
	$OpenFileDialog                  = New-Object System.Windows.Forms.OpenFileDialog
    $OpenFileDialog.initialDirectory = $initialDirectory
    $OpenFileDialog.Filter           = "CSVs and XMLs (*.csv,*.xml)|*.csv;*.xml"
    $OpenFileDialog.ShowDialog() | Out-Null
    $OpenFileDialog.filename
    $OpenFileDialog.Dispose()
}

#----- Function - Import CSV File -----#
Function PSCC-ImportCSV_XML
{
    $FilePathCurrent   = (Get-Item -Path ".\" -Verbose).FullName
    $FileName          = (PSCC-InputFile -initialDirectory "$FilePathCurrent") 
    if($FileName -like "*.xml"    )
    {
        $Users = Import-Clixml  $FileName
        $ItemCount         = ($Users | Measure-Object).Count
        $txtInputFile.Text = $FileName
        $txtItemCount.Text = $ItemCount
        $btnInputFile.Content = "Input File ($ItemCount)"    
    }
    elseif($FileName -like "*.csv")
    {
        $Users = Get-Content $FileName
        $ItemCount         = ($Users | Measure-Object).Count
        $txtInputFile.Text = $FileName
        $txtItemCount.Text = $ItemCount
        $btnInputFile.Content = "Input File ($($ItemCount - 1))"
    }
}

Function PSCC-GetConfigAsJSON
{
    $JSONConfig = @"
    {
        "AppId":  "$($txtConfigAppId.Text)",
        "TenantName":  "$($txtM365Tenant.Text)",
        "ThumbPrint":  "$($txtAppCertThumbprint.Text)",
        "OnPremises":  [
                        {
                            "PSVirtualDirectory":  "$($txtConfigAppId.Text)",
                            "VirtualDirectoryConfig":  "$($txtConfigAppId.Text)",
                            "ExOnPremUN":  "$($txtExOnPremUNCheck.Text)",
                            "PlaceHolder1":  {
                                                "Placeholder1sub1":  "",
                                                "Placeholder1sub2":  "",
                                                "Placeholder1sub3":  ""
                                            }
                        }
                    ],
        "Online":  [
                        {
                            "O365AdminUN":  "$($txtM365AdminUN.Text)",
                            "AuthType":  "$($txtAuthType.Text)",
                            "ExchangeOnline":  {
                                            "ExOnpremURI":  "$($txtExOnpremURI.Text)",
                                            "MigrationEndpoint":  "$($txtMigrationEndpoint.Text)",
                                            "ExOURI":  "$($txtExOURI.Text)",
                                            "Sleep":  "$($txtSleep.Text)",
                                            "Threshold":  "$($txtThreshold.Text)",
                                            "txtSourceMigUN":  "$($txtSourceMigUN.Text)",
                                            "ExMigrationType":  "$($txtExchangeType.Text)"
                                        },
                            "OneDrive_SharePointOnline":  {
                                            "SPOItemExceptions":  "$($txtSPOItemExceptions.Text)",
                                            "SPOFolderExceptions":  "$($txtSPOFolderExceptions.Text)",
                                            "SPOFileExtensionExceptions":  "$($txtSPOFileExtensionExceptions.Text)",
                                            "SPOAdminURL":  "$($txtSPOAdminURL.Text)"
                                        },
                            "ToolSettings":  {
                                            "UIReportingFrequency":  "$($txtUIReportingFrequency.Text)",
                                            "EnableCustomScripts":  "$($cBoxSettings_EnableCustomScriptTab.IsChecked)"
                                        },
                            "MSGraph":  {
                                            "ClientID":  "$($txtMSGraph_ClientID.Text)"
                                        }
                        }
                    ]
    }
"@
    return $JSONConfig
}

#----- Function - Load -----#
Function PSCC-LoadConfig($Actor)
{
    if($cBoxSelectConfig.SelectedItem -ne "Configuration File Not Found")
    {
        $ProgressBar = New-ProgressBar
        Write-ProgressBar -ProgressBar $ProgressBar -Activity "Importing configuration files." -PercentComplete 0 -CurrentOperation "Processing information..."
        $CurrentDirectory               = (Resolve-Path .\).Path
        $ConfigFile = "$CurrentDirectory\Config.json"
        $ResolveWorkingPath             = Test-Path -Path $ConfigFile
        if($ResolveWorkingPath -eq $true )
        {
            $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json 
            $ImportedConfigFileCount = ($ImportedConfigFile | Measure-Object).Count
            if($Actor -eq "btnConfigWindow_Load")
            {
                $txtM365AdminPWD.text = $Null
                $SearchValue = $datagridConfigWindow.SelectedValue.AppId
                $cBoxSelectConfig.SelectedItem = $SearchValue
            }
            if($Actor -eq "cBoxSelectConfig")
            {
                $txtM365AdminPWD.text = $Null
                $SearchValue = $cBoxSelectConfig.SelectedItem
            }
            $Processed = 0
            foreach($Tenant in $ImportedConfigFile)
            {
                Write-ProgressBar -ProgressBar $ProgressBar -Activity "Reading configuration files." -PercentComplete (($Processed/$ImportedConfigFileCount) * 100) -CurrentOperation "Reading $($Tenant.AppId)..."
                if($SearchValue -eq $Tenant.TenantName)
                {
                    $txtConfigAppId.Text         = $Tenant.AppId
                    $txtAppId.Text               = $Tenant.AppId
                    $txtAppCertThumbprint.Text               = $Tenant.Thumbprint
                    $txtM365Tenant.Text                = $Tenant.TenantName
                    $txtM365AdminUN.Text               = $Tenant.Online.O365AdminUN
                    $txtExOURI.Text                      = $Tenant.Online.ExchangeOnline.ExOURI
                    $txtExOnpremURI.Text                 = $Tenant.Online.ExchangeOnline.ExOnpremURI
                    $txtMigrationEndpoint.Text           = $Tenant.Online.ExchangeOnline.MigrationEndpoint
                    $txtSleep.Text                       = $Tenant.Online.ExchangeOnline.Sleep
                    $txtThreshold.Text                   = $Tenant.Online.ExchangeOnline.Threshold
                    $txtExchangeType.Text                = $Tenant.Online.ExchangeOnline.ExMigrationType
                    #$txtExOnPremUNCheck.Text             = $Tenant.Online.ExchangeOnline.ExOnPremUN #no field found by this name. review for onprem config later
                    $txtSourceMigUN.Text                 = $Tenant.Online.ExchangeOnline.ExOnPremUN
                    $txtSourceMigUN.Text                 = $Tenant.Online.SourceMigAdminUsername
                    $txtSPOFileExtensionExceptions.Text  = $Tenant.Online.OneDrive_SharePointOnline.SPOFileExtensionExceptions
                    $txtSPOAdminURL.Text                 = $Tenant.Online.OneDrive_SharePointOnline.SPOAdminURL
                    $txtSPOSource.text = $txtSPOAdminURL.text
                    $txtSPOItemExceptions.Text           = $Tenant.Online.OneDrive_SharePointOnline.SPOItemExceptions
                    $txtSPOFolderExceptions.Text         = $Tenant.Online.OneDrive_SharePointOnline.SPOFolderExceptions
                    $txtUIReportingFrequency.Text        = $Tenant.Online.ToolSettings.UIReportingFrequency
                    if($Tenant.Online.ToolSettings.EnableCustomScripts -ne $true)
                    {
                        $cBoxSettings_EnableCustomScriptTab.IsChecked  = $false
                    }
                    Else
                    {
                        $cBoxSettings_EnableCustomScriptTab.IsChecked  = $Tenant.Online.ToolSettings.EnableCustomScripts
                    }
                    $btnConfigWindow_Save.IsEnabled             = $True
                    if($txtAuthType.Text -eq "OAuth"        )
                    {
                        $checkBoxAuthType.ischecked = $true
                    }
                    if($txtAuthType.Text -eq "Basic"        )
                    {
                        $checkBoxAuthType.ischecked = $false
                    }
                    if($txtExchangeType.Text -eq "On-premises")
                    {
                        $checkBoxT2TMigrations.ischecked = $false
                    }
                    if($txtExchangeType.Text -eq "T2T")
                    {
                        $checkBoxT2TMigrations.ischecked = $true
                    }
                    #$txtPSVirtualDirectory.Text = $Tenant.OnPremises.PSVirtualDirectory
                    #$lblSSLRequired.content     = $Tenant.OnPremises.VirtualDirectoryConfig
                    #if($lblSSLRequired.content -eq "Https://"){$cbUseSSL.ischecked              = $true }
                    #if($lblSSLRequired.content -eq "Http://" ){$cbUseSSL.ischecked              = $false}
                }
                $Processed ++
            }
            Write-ProgressBar -ProgressBar $ProgressBar -Activity "Reading configuration files." -PercentComplete 100 -CurrentOperation "Import complete."
            if($Actor -eq "btnConfigWindow_Load")
            {
                PSCC-Refresh -Actor "btnConfigWindow_Load"
            }
            else
            {
                PSCC-Refresh
            }
            Write-ProgressBar -ProgressBar $ProgressBar -Activity "Reading configuration files." -PercentComplete 100 -CurrentOperation "Import complete."
            Start-Sleep 1
            Close-ProgressBar $ProgressBar
        }
    }
}

    #----- Function - Start -----#
Function PSCC-Start
{
    $StartError = @()
    if($txtInputFileRequired.text -eq "True")
    {
        If((!$txtInputFile.Text) -or ($txtInputFile.Text -eq "Please select an input file"))
        {
            $StartError     += "Missing Input File"
        }
    }
    if($($txtMigrationBatchName.Visibility) -eq "Visible")
    {
        if($($txtMigrationEndpoint.text) -eq "")
        {
            $StartError     += "Missing Migration Endpoint Name"
        }
        if($($txtMigrationBatchName.text) -eq "")
        {
            $StartError     += "Missing Migration Batch Name"
        }
    }
    If($checkBoxOverride.IsChecked -eq $true)
    {
        if($cBoxOverride.SelectedItem -eq $null)
        {
            $StartError     += "Override method is enabled but no script selected"
        }
        else
        {
            $ExecutionType                         = (($cBoxOverride.SelectedItem) -replace ".ps1","")
            $txtRequireSPOSiteProcessingFirst.Text = $false
            $txtRequireMSOLProcessingFirst.Text    = $false
            $IsCustom                              = $true
            $ExecutionName                         = $ExecutionType
        }   
    }
    If($checkBoxOverride.IsChecked -eq $false)
    {
        $ExecutionType                             = $txtExecutionMethod.Text
        $ExecutionName                             = $txtExecutionMethodName.Text
        $PassedParameters                          = $null
        $IsCustom                                  = $false
        if($ExecutionType -eq "M365")
        {
            $StartError     += "Missing Execution Type"
        }
    }
    If($ExecutionType -eq "")
    {
        $StartError     += "Missing Execution Type"
    }
    If($cBoxThreads.Text -eq "")
    {
        $StartError     += "Missing Thread Count"
    }
    if($txtTargetEnvironmentSelection.text -eq "gridM365")
    {
        if($tabcontrolM365.SelectedItem.Name -eq "tabitemSPO")
        {
            if($txtSPOAdminURL.text -eq "")
            {
                $StartError     += "Missing SharePoint Online Admin URL"
            }
        }
        if($tabcontrolM365.SelectedItem.Name -eq "tabitemExO")
        {
            If (($btnSourceMig.IsEnabled -eq $True) -and ($checkBoxT2TMigrations.ischecked -eq $false))
            {
                if($txtSourceMigUN.text -eq "")
                {
                    $StartError     += "Missing Source Exchange Migration Account Username"
                }
                if($txtSourceMigPWD.text -eq "")
                {
                    $StartError     += "Missing Source Exchange Migration Account Password"
                }
            }
            if(($txtExOnpremURI.text -eq "") -and ($ExchangeMigType -eq "On-premises") -and ($btnSourceMig.IsEnabled -eq $True))
            {
                $StartError     += "Missing On-premises Exchange URI"
            }
            if(($txtExOnpremURI.text -eq "") -and ($ExchangeMigType -eq "T2T") -and ($btnSourceMig.IsEnabled -eq $True))
            {
                $StartError     += "Missing Remote Tenant Name"
            }
            if($txtExOURI.Text -eq "")
            {
                $StartError     += "Missing Exchange Online URI"
            }
        }
        If($txtM365Tenant.Text -like "Please first login to Office 365*")
        {
            $StartError     += "Missing Tenant Name (Connect to MSOL)"
        }
        if($ExecutionType -eq "SharePointOnline_A3_GetSiteItemInformation")
        {
            if($txtSPOItemExceptions.text -eq "")
            {
                $StartError     += "Missing declaration of 'Item Size Exceptions (MB)' in settings"
            }
            if($txtSPOFolderExceptions.text -eq "")
            {
                $StartError     += "Missing declaration of 'Folder Count Exceptions' in settings"
            }
        }
    }
    if($txtTargetEnvironmentSelection.text -eq "gridOnpremises")
    {
        if(($txtPSVirtualDirectory.text -eq "Please enter your virtual directory endpoint name") -or ($txtPSVirtualDirectory.text -eq ""))
        {
            $StartError     += "Missing powershell virtual directory endpoint name"
        }
        if(($txtExOnPremUNCheck.text -eq "Invalid admin credentials") -or ($txtExOnPremUNCheck.text -eq "Unchecked"))
        {
            $StartError     += "Please verify Exchange Admin Credentials"
        }
        if($txtExRemotePSCheck.text -ne "Connection Established")
        {
            if($txtExRemotePSCheck.text -eq "Failed to create session")
            {
                $StartError     += "Failed to connect to Exchange on-premises powershell"
            }
            if($txtExRemotePSCheck.text -eq "Failed to import session")
            {
                $StartError     += "Failed to connect to Exchange on-premises powershell"
            }
            if($txtExRemotePSCheck.text -eq "Unchecked")
            {
                $StartError     += "Please connect to Exchange on-premises powershell"
            }
        }
        if($txtADRemotePSCheck.text -ne "Connection Established")
        {
            if($txtADRemotePSCheck.text -eq "Connection Failed: Need RSAT")
            {
                $StartError     += "RSAT administration tools are not installed"
            }
            if($txtADRemotePSCheck.text -eq "Unchecked")
            {
                $StartError     += "Please connect to active directory"
            }
        }
    }
    if(!$StartError)
    {
        if(($ExecutionType -eq "ExchangeOnline_ResumeMoveRequest") `
        -or ($ExecutionType -eq "ExchangeOnline_ImmediateCutoverMoveRequest") `
        -or ($ExecutionType -eq "ExchangeOnline_RemoveMoveRequest") `
        -or ($ExecutionType -eq "MSOnlineService_FromFederatedToManagedUPN") `
        -or ($ExecutionType -eq "MSOnlineService_PermanentlyRemoveMSOLUser") `
        -or ($ExecutionType -eq "SharePointOnline_SetSite_ReadOnly") `
        -or ($ExecutionType -eq "SharePointOnline_SetSiteCollectionAdmin") `
        -or ($IsCustom -eq $true))
        {
            if($checkBoxConfirmExecution.IsChecked -eq $true )
            {
                $PassedConfirmation = $true
            }
            if($checkBoxConfirmExecution.IsChecked -eq $false)
            {
                $btndConfirmExecutionWindow_Confirm.IsEnabled = $false
                if($IsCustom -eq $true)
                {
                    $txtdConfirmExecutionWindow_Info.Text = "Warning: You have enabled the execution of a custom module, are you sure you wish to continue?"
                }
                else
                {
                    $txtdConfirmExecutionWindow_Info.Text = "Warning: The module `"$ExecutionName`" is scoped to read and write to the designated identity/tenant. Are you sure you wish to continue?"
                }
                $gridConfirmExecutionWindow.visibility = "Visible"
                $PassedConfirmation = $false
            }
        }
        else
        {
            $PassedConfirmation = $true
        }
    }
    If((!$StartError) -and ($PassedConfirmation -eq $true))
    {
        $checkBoxConfirmExecution.IsChecked = $false
        $DateTime                       = (Get-Date -Format "yyyyMMdd-HHmmss").tostring() #Current Date and Time
        $PassedParameters               = $txtOMParameters.Text
        $SleepThreshold                 = $txtSleep.text
        $SPOItemExceptions              = $txtSPOItemExceptions.text
        $SPOFolderExceptions            = $txtSPOFolderExceptions.text
        $SPOFileExtensionExceptions     = $txtSPOFileExtensionExceptions.text
        $ActiveThreshold                = $txtThreshold.text
        $UIReportingFrequency           = $txtUIReportingFrequency.text
        $SourceMigrationUserName        = $txtSourceMigUN.text
        $SourceMigrationPassword        = $txtSourceMigPWD.text
        $SourceMigrationPassword        = $SourceMigrationPassword -replace ("'","''")
        $ExOURI                         = $txtExOURI.text
        $ExOnpremURI                    = $txtExOnpremURI.text
        $ItemCount                      = $txtItemCount.Text
        $Dividedcount                   = $ItemCount/$cBoxThreads.Text
        $ExchangeMigType                = $txtExchangeType.text
        $AuthType                       = $txtAuthType.text
        $ThreadTracking                 = @()
        $mailboxuserfilelocation        = $txtInputFile.Text
        $ExOStartDate                   = $DatePickerExOStartDate.SelectedDate
        $ExOEndDate                     = $DatePickerExOEndDate.SelectedDate
        $CurrentDirectory               = (Resolve-Path .\).Path
        $ScriptDirectory                = "$CurrentDirectory\Modules"
        $ExecutionFile                  = $ExecutionType

        $AppId                         = $txtAppId.Text
        $TenantLong                    = $txtM365Tenant.Text
        $TenantShort                    = $TenantLong.Split('.')[0]

        $SPOAdminURL                   = $txtSPOAdminURL.Text
        $AppCertThumbprint             = $txtAppCertThumbprint.Text
        $MigrationEndpoint = $txtMigrationEndpoint.Text
        $MigrationBatchName = $txtMigrationBatchName.Text

        if($checkBoxOverride.isChecked -eq $true)
        {
            $ExecutionFile              = ($cBoxOverride.SelectedItem) -replace ".ps1",""
            $ScriptDirectory            = $CurrentDirectory
        }
        if(($txtRequireSPOSiteProcessingFirst.Text -eq "True") -or ($txtRequireMSOLProcessingFirst.Text -eq "True"))
        {#Create popup notification
            $ProgressBar = New-ProgressBar
            Write-ProgressBar -ProgressBar $ProgressBar -Activity "Pre-processing activity." -PercentComplete 0 -CurrentOperation "Please wait while PSCC preforms a pre-processing task. The could take several minutes and PSCC may become unresponsive in that time. Rest assured, it is processing. At this time, the loading bar may not progress."
        }
        if($txtRequireSPOSiteProcessingFirst.Text -eq "True")
        {
            $TempFileName               = ""
            $TempFileName               = [System.IO.Path]::GetTempFileName()
            $error.Clear()
            $FullOutputPath                 = "$CurrentDirectory\$TenantShort"
            $FullWorkingPath                = "$FullOutputPath\Threads"
            $ResolveWorkingPath             = Test-Path -Path $FullWorkingPath
            if($ResolveWorkingPath -eq $false)
            {
                Write-host "Output directory not found.  Creating output directory."
                mkdir $FullWorkingPath
            }
            $ExecutionLogOutputPath = "$CurrentDirectory\RuntimeLogs\"
            $ExecutionLog                        = "$TenantShort.$ExecutionType.ExecutionLog.1.$datetime.log"
            $ResolveExecutionLog             = Test-Path -Path $ExecutionLogOutputPath
            if($ResolveExecutionLog -eq $false)
            {
                mkdir $ExecutionLogOutputPath
            }
            $FullStandardErrorOutputPath    = "$ExecutionLogOutputPath$ExecutionLog" -replace ".xml",".csv"
            $SPOQuickRun      = "-noprofile & '$ScriptDirectory\$ExecutionFile.ps1' -DateTime '$datetime' -ExecutionMethod '$ExecutionType' -TenantShort '$TenantShort' -OutputFolder '$FullWorkingPath' -NumExecutions '1' -UIReportingFrequency '1' -SPOAdminURL '$SPOAdminURL'"
            $SPOPreProcess = Start-Process powershell -ArgumentList "$SPOQuickRun -AppId '$AppId' -Thumbprint '$AppCertThumbprint' -MailFile '$logfile' -OutputFileNumber '1'" -PassThru -RedirectStandardError $FullStandardErrorOutputPath
            $SPOPreProcess.WaitForExit()
            $SPOSeedOutputFile           = "$FullWorkingPath\$ExecutionType.Results.InitialSeed.$DateTime.csv"
            $AllSPOSites = Import-Csv $SPOSeedOutputFile
            [double]$AllSPOSitesCount   = ($AllSPOSites | measure).Count
            [double]$Dividedcount       = $AllSPOSitesCount/[double]$cBoxThreads.Text
            $mailboxuserfilelocation    = $SPOSeedOutputFile
            Write-ProgressBar -ProgressBar $ProgressBar -Activity "Pre-processing activity." -PercentComplete 100 -CurrentOperation "Pre-processing has completed. Closing..."
            Close-ProgressBar $ProgressBar
            $ExecutionType = "SharePointOnline_A1_GetSiteDetails"
            $ExecutionFile = $ExecutionType
        }
        if($txtRequireMSOLProcessingFirst.Text -eq "True")
        {
            $TempFileName               = ""
            $TempFileName               = [System.IO.Path]::GetTempFileName()
            $Activities                 = Get-MsolUser -All
            $NumToUpdate = ($Activities | Measure-Object).Count
            $Processed = 0
            Foreach($Activity in $Activities)
            {
                Write-ProgressBar -ProgressBar $ProgressBar -Activity "Pre-processing activity." -PercentComplete (($Processed/$NumToUpdate) * 100) -CurrentOperation "Processing information..."
                $ProxyAddresses         = $Activity.ProxyAddresses -join ";"
                $UserData               = New-Object PSObject
                $UserData | Add-Member NoteProperty BlockCredential $Activity.BlockCredential
                $UserData | Add-Member NoteProperty CloudExchangeRecipientDisplayType $Activity.CloudExchangeRecipientDisplayType
                $UserData | Add-Member NoteProperty DisplayName $Activity.DisplayName
                $UserData | Add-Member NoteProperty Errors $Activity.Errors
                $UserData | Add-Member NoteProperty ImmutableId $Activity.ImmutableId
                $UserData | Add-Member NoteProperty IsLicensed $Activity.IsLicensed
                $UserData | Add-Member NoteProperty LastDirSyncTime $Activity.LastDirSyncTime
                $UserData | Add-Member NoteProperty LicenseReconciliationNeeded $Activity.LicenseReconciliationNeeded
                $UserData | Add-Member NoteProperty LiveId $Activity.LiveId
                $UserData | Add-Member NoteProperty MSExchRecipientTypeDetails $Activity.MSExchRecipientTypeDetails
                $UserData | Add-Member NoteProperty ObjectId $Activity.ObjectId
                $UserData | Add-Member NoteProperty OverallProvisioningStatus $OActivity.verallProvisioningStatus
                $UserData | Add-Member NoteProperty PasswordNeverExpires $Activity.PasswordNeverExpires
                $UserData | Add-Member NoteProperty ProxyAddresses $ProxyAddresses
                $UserData | Add-Member NoteProperty SignInName $Activity.SignInName
                $UserData | Add-Member NoteProperty UsageLocation $Activity.UsageLocation
                $UserData | Add-Member NoteProperty UserPrincipalName $Activity.UserPrincipalName
                $UserData | Add-Member NoteProperty UserType $Activity.UserType
                $UserData | Add-Member NoteProperty WhenCreated $Activity.WhenCreated
                $UserData | Add-Member NoteProperty Error      $Error[0].Exception.Message
                $UserData | Export-Csv  $TempFileName -NoTypeInformation -Append
                $Processed ++
            }
            [double]$ActivityCount      = $Activities.count
            [double]$Dividedcount       = $ActivityCount/[double]$cBoxThreads.Text
            $mailboxuserfilelocation    = $TempFileName
            Write-ProgressBar -ProgressBar $ProgressBar -Activity "Pre-processing activity." -PercentComplete 100 -CurrentOperation "Pre-processing has completed. Closing..."
            Close-ProgressBar $ProgressBar
        }
        if($txtEnforceSingleThread.text -eq "True")
        {
            $NumExecutions = 1
        }
        else
        {
            if(($mailboxuserfilelocation -like "*.csv") -or ($mailboxuserfilelocation -like "*.tmp"))
            {
                $DecimalRemoved                 = "{0:N0}" -f $Dividedcount -replace ",",""
                $count                          = [math]::floor($DecimalRemoved) + 1
                $NumExecutions = Get-Content $mailboxuserfilelocation -ReadCount:$Count | measure | % { $_.Count }
                $Header                         = Get-Content $mailboxuserfilelocation -TotalCount:1
            }
            Elseif($mailboxuserfilelocation -like "*.xml")
            {
                $DecimalRemoved                 = "{0:N0}" -f $Dividedcount -replace ",",""
                $count                          = [math]::floor($DecimalRemoved) + 1
                $NumExecutions = $cBoxThreads.Text
            }
        }
        $Part                           = 1
        $FullOutputPath                 = "$CurrentDirectory\$TenantShort"
        $FullWorkingPath                = "$FullOutputPath\Threads"
        $ResolveWorkingPath             = Test-Path -Path $FullWorkingPath
        if($ResolveWorkingPath -eq $false)
        {
            Write-host "Output directory not found.  Creating output directory."
            mkdir $FullWorkingPath
        }
        $StandardExecutionSettings      = "-noprofile & '$ScriptDirectory\$ExecutionFile.ps1' -TenantShort '$TenantShort' -DateTime '$datetime' -ExecutionMethod '$ExecutionType' -OutputFolder '$FullWorkingPath' -NumExecutions '$NumExecutions' -UIReportingFrequency '$UIReportingFrequency' -AppId '$AppId' -Thumbprint '$AppCertThumbprint' $PassedParameters"
        $ExchangeOnlineSettings         = "-ExchangeMigrationType '$ExchangeMigType' -ExOURI '$ExOURI' -ExOnpremURI '$ExOnpremURI' -SourceMigrationUserName '$SourceMigrationUserName' -SourceMigrationPassword '$SourceMigrationPassword' -SleepThreshold '$SleepThreshold' -ActiveThreshold '$ActiveThreshold' -ExOStartDate '$ExOStartDate' -ExOEndDate '$ExOEndDate' -MigrationEndpoint '$MigrationEndpoint' -MigrationBatchName '$MigrationBatchName'"
        $SharePointOnlineSettings       = "-SPOAdminURL '$SPOAdminURL' -SPOFolderExceptions '$SPOFolderExceptions' -SPOItemExceptions '$SPOItemExceptions' -SPOFileExtensionExceptions '$SPOFileExtensionExceptions' -SPODestinationGEO '$($cBoxSPODestination.text)'"
        $MSGraphSettings                = "-ClientID '$ClientID' -TenantID '$TenantID'"
        if($txtEnforceSingleThread.text -eq "False")
        {
            $cBoxSingleSeedFile.isChecked
            if($cBoxSingleSeedFile.isChecked -eq $true)
            {
                $RequiresSingleSeedFile     = "True"
                $logfile                    = "$FullWorkingPath\$ExecutionType.UserList.SingleSeed.$datetime.csv"
                $SeedFileVar                = Import-Csv $mailboxuserfilelocation
                $SeedFileVar | Export-Csv $logfile -NoTypeInformation
                $AccountNumber = 0
                for($SeedThread = 1; $seedThread -le $cBoxThreads.Text; $SeedThread++)
                {
                    $ExecutionLogOutputPath = "$CurrentDirectory\RuntimeLogs\"
                    $ExecutionLog                        = "$TenantShort.$ExecutionType.ExecutionLog.$part.$datetime.log"
                    $ResolveExecutionLog             = Test-Path -Path $ExecutionLogOutputPath
                    if($ResolveExecutionLog -eq $false)
                    {
                        mkdir $ExecutionLogOutputPath
                    }
                    $FullStandardErrorOutputPath    = "$ExecutionLogOutputPath$ExecutionLog" -replace ".xml",".csv"
                    $ThreadTracking        += Start-Process powershell -ArgumentList "$StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part'" -PassThru -RedirectStandardError $FullStandardErrorOutputPath
                    write-host     "1 Multi-thread, no sorting and single seed file: $StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part' -PassThru -RedirectStandardError $FullStandardErrorOutputPath"
                    $AccountNumber ++
                }
            }
            if($cBoxSingleSeedFile.isChecked -eq $false)
            {
                $RequiresSingleSeedFile     = "False"
                $AccountNumber = 0
                if(($mailboxuserfilelocation -like "*.csv") -or ($mailboxuserfilelocation -like "*.tmp"))
                {
                    Get-Content $mailboxuserfilelocation -ReadCount:$Count | % {
                        $logfile                = "$FullWorkingPath\$ExecutionType.UserList.$part.$datetime.csv"
                        if ($Part -gt 1)
                        {
                            Set-Content -path $logfile -value $Header
                        }
                        Add-Content -path $logfile -value $_
                        if($checkBoxOverride.isChecked -eq $true)
                        {
                            $ExecutionFile      = ($cBoxOverride.SelectedItem) -replace ".ps1",""
                            $ScriptDirectory    = $CurrentDirectory
                        }
                        $ExecutionLogOutputPath = "$CurrentDirectory\RuntimeLogs\"
                        $ExecutionLog                        = "$TenantShort.$ExecutionType.ExecutionLog.$part.$datetime.log"
                        $ResolveExecutionLog             = Test-Path -Path $ExecutionLogOutputPath
                        if($ResolveExecutionLog -eq $false)
                        {
                            Write-host "ExecutionLog directory not found.  Creating output directory."
                            mkdir $ExecutionLogOutputPath
                        }
                        $FullStandardErrorOutputPath    = "$ExecutionLogOutputPath$ExecutionLog" -replace ".xml",".csv"
                        $ThreadTracking        += Start-Process powershell -ArgumentList "$StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part'" -PassThru -RedirectStandardError $FullStandardErrorOutputPath
                        write-host     "2 Multi-Thread, Multi-File and no sorting (CSV): $StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part' -PassThru -RedirectStandardError $FullStandardErrorOutputPath"
                        $Part                  += 1
                        $AccountNumber ++
                    }
                }
                elseif($mailboxuserfilelocation -like "*.xml")
                {#If the imported file is a csv
                    $xml = Import-Clixml $mailboxuserfilelocation
                    $xmlcount = ($xml | measure).Count
                    $parsedXML = @()
                    $Current = 1
                    $IncrementalCount = $count
                    $AccountNumber = 0
                    $UserThreadGroup            = $cBoxM365ThreadGroup.SelectedItem
                    $SearchValue = "$TenantShort|$UserThreadGroup"
                    $AllPSCCThreadGroupUsers = Get-StoredCreds
                    $UsersInThreadGroup = $AllPSCCThreadGroupUsers | Where-Object { $_.Comment -eq $SearchValue } | Sort-Object UserName
                    $CredAccountsAvaialble = ($UsersInThreadGroup | measure).count
                    foreach($subject in $xml)
                    {
                        $Added = $null
                        if($Current -le $count)
                        {
                            $parsedXML += $subject
                            $Added = $true
                        }
                        if(($Current -eq $count) -or ($Current -eq $xmlcount))
                        {
                            $logfile                = "$FullWorkingPath\$ExecutionType.UserList.$part.$datetime.xml"
                            if($Added -ne $true)
                            {
                                $parsedXML += $subject
                            }
                            $parsedXML | Export-Clixml $logfile -Depth 10
                            if($checkBoxOverride.isChecked -eq $true)
                            {
                                $ExecutionFile      = ($cBoxOverride.SelectedItem) -replace ".ps1",""
                                $ScriptDirectory    = $CurrentDirectory
                            }
                            $ExecutionLogOutputPath = "$CurrentDirectory\RuntimeLogs\"
                            $ExecutionLog                        = "$TenantShort.$ExecutionType.ExecutionLog.$part.$datetime.log"
                            $ResolveExecutionLog             = Test-Path -Path $ExecutionLogOutputPath
                            if($ResolveExecutionLog -eq $false)
                            {
                                Write-host "ExecutionLog directory not found.  Creating output directory."
                                mkdir $ExecutionLogOutputPath
                            }
                            $FullStandardErrorOutputPath    = "$ExecutionLogOutputPath$ExecutionLog" -replace ".xml",".csv"
                            $ThreadTracking        += Start-Process powershell -ArgumentList "$StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part'" -PassThru -RedirectStandardError $FullStandardErrorOutputPath
                            write-host     "3 Multi-Thread, Multi-File and no sorting (XML): $StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part' -PassThru -RedirectStandardError $FullStandardErrorOutputPath"
                            $Part                  += 1
                            $count = $count + $IncrementalCount
                            $parsedXML = @()
                            $AccountNumber ++
                        }
                        $current ++
                    }
                }
            }
        }
        if($txtEnforceSingleThread.text -eq "True")
        {
            if($checkBoxOverride.isChecked -eq $true)
            {
                $ExecutionFile      = ($cBoxOverride.SelectedItem) -replace ".ps1",""
                $ScriptDirectory    = $CurrentDirectory
            }
            $ExecutionLogOutputPath = "$CurrentDirectory\RuntimeLogs\"
            $ExecutionLog                        = "$TenantShort.$ExecutionType.ExecutionLog.$part.$datetime.log"
            $ResolveExecutionLog             = Test-Path -Path $ExecutionLogOutputPath
            if($ResolveExecutionLog -eq $false)
            {
                Write-host "ExecutionLog directory not found.  Creating output directory."
                mkdir $ExecutionLogOutputPath
            }
            $FullStandardErrorOutputPath    = "$ExecutionLogOutputPath$ExecutionLog"
            $ThreadTracking        += Start-Process powershell -ArgumentList "$StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part'" -PassThru -RedirectStandardError $FullStandardErrorOutputPath
            write-host                             "4 Enforce Single Thread: $StandardExecutionSettings $ExchangeOnlineSettings $SharePointOnlineSettings $MSGraphSettings -RequiresSingleSeedFile '$RequiresSingleSeedFile' -MailFile '$logfile' -OutputFileNumber '$Part' -PassThru -RedirectStandardError PSCCExecutionFailure.log"
        }
        if($ThreadTracking)
        {
            $ThreadMonitoringAgent = New-ThreadMonitor
            $TenantInfoText = "Connected to: $TenantLong"
            $ScriptInfoText = "Executing: $ExecutionName"
            $ProcessCount               = ($ThreadTracking | Measure-Object).Count
            $WindowHeight               = 125 + ($ProcessCount * 25)
            $tNum = 1
            $ManagedThreads = @()
            $ThreadedProcesses = @()
            foreach($PSThread in $ThreadTracking)
            {
                $ProcessInfo  = New-Object psobject
                $ProcessInfo | Add-Member NoteProperty ID               $PSThread.id
                $ProcessInfo | Add-Member NoteProperty MainWindowTitle  $PSThread.MainWindowTitle
                $ProcessInfo | Add-Member NoteProperty StartTime        $PSThread.StartTime
                $ProcessInfo | Add-Member NoteProperty MainWindowHandle $PSThread.MainWindowHandle
                $ProcessInfo | Add-Member NoteProperty Status           $PSThread.Status
                $ProcessInfo | Add-Member NoteProperty HasCompleted     $($false)
                $ProcessInfo | Add-Member NoteProperty ThreadNumber     $tNum
                $tNum ++
                $ThreadedProcesses += $ProcessInfo
            }
            do
            {
                $FoundMangedThreads = @()
                $NotFoundMangedThreads = @()
                $allPowerShellProcess = Get-Process PowerShell
                foreach($PSProcess in $allPowerShellProcess)
                {
                    if($ThreadedProcesses.id -contains $PSProcess.Id)
                    {
                        if($PSProcess.MainWindowTitle -like "* | Complete")
                        {
                            $HasCompleted = $true
                        }
                        else
                        {
                            $HasCompleted = $false
                        }
                        $ProcessInfo  = New-Object psobject
                        $ProcessInfo | Add-Member NoteProperty ID               $PSProcess.id
                        $ProcessInfo | Add-Member NoteProperty MainWindowTitle  $PSProcess.MainWindowTitle
                        $ProcessInfo | Add-Member NoteProperty StartTime        $PSProcess.StartTime
                        $ProcessInfo | Add-Member NoteProperty MainWindowHandle $PSProcess.MainWindowHandle
                        $ProcessInfo | Add-Member NoteProperty Status           "Found"
                        $ProcessInfo | Add-Member NoteProperty HasCompleted     $HasCompleted
                        $ProcessInfo | Add-Member NoteProperty ThreadNumber     ($ThreadedProcesses | where {$PSProcess.Id -eq $_.ID}).ThreadNumber
                        $FoundMangedThreads += $ProcessInfo                        
                    }
                }
                foreach($PSThread in $ThreadedProcesses)
                {
                    if($allPowerShellProcess.id -notcontains $PSThread.Id)
                    {
                        $HasCompleted = "NotFound"
                        foreach($ManagedThread in $ManagedThreads)
                        {
                            if($ManagedThread.id -eq $PSThread.id)
                            {
                                $HasCompleted = $ManagedThread.HasCompleted
                            }
                        }
                        $ProcessInfo  = New-Object psobject
                        $ProcessInfo | Add-Member NoteProperty ID               $PSThread.id
                        $ProcessInfo | Add-Member NoteProperty MainWindowTitle  "NotFound"
                        $ProcessInfo | Add-Member NoteProperty StartTime        "NotFound"
                        $ProcessInfo | Add-Member NoteProperty MainWindowHandle "NotFound"
                        $ProcessInfo | Add-Member NoteProperty Status           "NotFound"
                        $ProcessInfo | Add-Member NoteProperty HasCompleted     $HasCompleted
                        $ProcessInfo | Add-Member NoteProperty ThreadNumber     $PSThread.ThreadNumber
                        $NotFoundMangedThreads += $ProcessInfo
                    }
                }
                $ManagedThreads = @()
                $ManagedThreads += $FoundMangedThreads
                $ManagedThreads += $NotFoundMangedThreads
                $ManagedThreads = $ManagedThreads | sort ThreadNumber
                Write-ThreadMonitor -ProgressBar $ThreadMonitoringAgent -Processes $ManagedThreads -TenantInfoText $TenantInfoText -ScriptInfoText $ScriptInfoText -WindowHeight $WindowHeight
                Start-Sleep -Seconds 1
            } while($ThreadMonitoringAgent.RunspaceWindow.IsVisible -eq $true)
        }
    }
    if($TempFileName)
    {
        Remove-Item $TempFileName -Force
    }
    if($StartError)
    {
        $datagridStartFailureWindow.Items.Clear()
        foreach($Issue in $StartError)
        {
            $datagridStartFailureWindow.AddChild([pscustomobject]@{
                Error=$Issue
            })
        }
        $gridStartFailureWindow.Visibility = "Visible"
    }
}

#----- Function - Checks the Prerequisites for Credentialing -----#
Function CheckCredManPreReqs
{
    $error.Clear()
    $LoadCredMgr = Get-Module CredentialManager -ListAvailable
    If($LoadCredMgr)
    {
        $error.Clear()
        Import-Module CredentialManager -ErrorAction SilentlyContinue
        if($error)
        {
            Write-Host "Failed to load the CredentialManager 2.0 PowerShell module" -ForegroundColor Red
        }
    }
    else
    {
        Write-Host "The CredentialManager 2.0 PowerShell module not installed. If you plan to create/manage standalone thread accounts, please run Install-Module CredentialManager" -ForegroundColor Yellow
    }
}
Function CheckConfigfile
{
    $CurrentDirectory                    = (Resolve-Path .\).Path
    $ConfigFile                          = "$CurrentDirectory\Config.json"
    $ResolveWorkingPath                  = Test-Path -Path $ConfigFile
    if($ResolveWorkingPath -eq $false)
    {
        Write-host "No PSCC Connection Configuration file was found. Please select the `"Connections`" button to create new connections" -ForegroundColor Yellow
    }
}
#----- Function - Checks the Prerequisites for PowerShell Versioning -----#
Function CheckPSPreReqs
{
    $PSVersion = $host.Version.Major
    if($PSVersion -lt "3")
    {
        $txtPSPreReqs.Text       = "v$PSVersion. v3 or greater is required"
        $txtPSPreReqs.Foreground = "Red"
        Write-Host "You do not meet minimum requirements of PowerShell 3.0 or greater" -ForegroundColor Red
        Write-Host "Please go to aka.ms/wmf to obtain the latest version of the Windows Management Framework" -ForegroundColor Yellow
        Break
    }
    if($PSVersion -ge "3")
    {
        $txtPSPreReqs.Text       = "Version $PSVersion"
        $txtPSPreReqs.Foreground = "Green"
    }
}
        
#----- Function - Checks the Prerequisites for use of MSOnline -----#
Function CheckMSOPreReqs
{
    $CheckMSOnlineModule = Get-Module -ListAvailable "MSOnline"
    if($CheckMSOnlineModule.Name -eq "MSOnline")
    {
        $txtMSOPreReqs.Text       = "Detected"
        $txtMSOPreReqs.Foreground = "Green"
    }
    else
    {
        Write-Host "MSOnline Module is not installed. Please run 'Install-Module MSOnline' if it is required." -ForegroundColor Yellow
        $txtMSOPreReqs.Text       = "Please run 'Install-Module MSOnline'"
        $txtMSOPreReqs.Foreground = "Red"
    }
}

#----- Function - Checks the Prerequisites for use of SharePoint Online -----#
Function CheckSPOPreReqs
{
    $CheckCSOM      = [System.Reflection.Assembly]::LoadWithPartialName("Microsoft.SharePoint.Client.UserProfiles")
    $CheckSPOModule = Get-Module -ListAvailable "Microsoft.Online.SharePoint.PowerShell"
    if(($CheckSPOModule.Name -eq $null) -and (!$CheckCSOM))
    {
        Write-Host "You do not meet the requirements for the SharePoint Online Management Shell. Please visit aka.ms/SPOMS to download the latest version of the SharePoint Online Management Shell; if it is required." -ForegroundColor Yellow
        Write-Host "You do not meet the requirements for the SharePoint Online Client Components SDK (CSOM). Please visit aka.ms/SPOCSOM to download the latest version; if it is required." -ForegroundColor Yellow
        $txtSPOPreReqs.Text       = "Module: Not Detected | CSOM: Not Detected"
        $txtSPOPreReqs.Foreground = "Red"
    }
    if(($CheckSPOModule.Name -eq $null) -and ($CheckCSOM))
    {
        Write-Host "You do not meet the requirements for SharePoint Online. Please visit https://go.microsoft.com/fwlink/p/?LinkId=255251 to download the latest version of the SharePoint Online Management Shell and https://www.microsoft.com/en-us/download/details.aspx?id=42038 to download SharePoint Online Client Components SDK; if it is required." -ForegroundColor Yellow
        $txtSPOPreReqs.Text       = "Module: Not Detected | CSOM: Detected"
        $txtSPOPreReqs.Foreground = "Orange"
    }
    if(($CheckSPOModule.Name -eq "Microsoft.Online.SharePoint.PowerShell") -and (!$CheckCSOM))
    {
        Write-Host "You do not meet the requirements for SharePoint Online Client Components SDK (CSOM). Please visit aka.ms/spocsom to download the latest version; if it is required." -ForegroundColor Yellow
        $txtSPOPreReqs.Text       = "Module: Detected | CSOM: Not Detected"
        $txtSPOPreReqs.Foreground = "Orange"
    }
    if(($CheckSPOModule.Name -eq "Microsoft.Online.SharePoint.PowerShell") -and ($CheckCSOM))
    {
        $txtSPOPreReqs.Text       = "Module: Detected | CSOM: Detected"
        $txtSPOPreReqs.Foreground = "Green"
    }
}

<#
#----- Function - Checks the Prerequisites for use of AzureAD RMS -----#
Function CheckAIPService
{
    $CheckAIPService = Get-Module -ListAvailable "AIPService"
    if($CheckAIPService.Name -eq "AIPService")
    {
        $txtAIPService.Text       = "Detected"
        $txtAIPService.Foreground = "Green"
    }
    else
    {
        Write-Host "You do not meet the requirements for Azure Information Protection Service. Please run 'Install-Module -Name AIPService' if it is required." -ForegroundColor Yellow
        $txtAIPService.Text       = "Not Detected"
        $txtAIPService.Foreground = "Red"
    }
}
#>
#----- Function - Checks the Prerequisites for use of Skype for Business Online -----#
Function CheckS4BOPreReqs
{
    $CheckS4BOPreReqs = Get-Module -ListAvailable "SkypeOnlineConnector"
    if($CheckS4BOPreReqs.Name -eq "SkypeOnlineConnector")
    {
        $txtS4BOPreReqs.Text = "Detected"
        $txtS4BOPreReqs.Foreground = "Green"
    }
    else
    {
        Write-Host "You do not meet the requirements for Skype for Business Online. Please visit https://go.microsoft.com/fwlink/p/?LinkId=532439 to download the latest version if it is required." -ForegroundColor Yellow
        $txtS4BOPreReqs.Text = "Not Detected"
        $txtS4BOPreReqs.Foreground = "Red"
    }
}

   
#endregion
#=======================================================================================

#=======================================================================================
#region GUI
#=======================================================================================

[void][System.Reflection.Assembly]::LoadWithPartialName('presentationframework')

$CurrentDirectory               = (Resolve-Path .\).Path    
[xml]$XAML = Get-Content "$CurrentDirectory\PSCCUI.xml" -Raw

#endregion
#=======================================================================================

#=======================================================================================
#region Handlers
#=======================================================================================
$Reader                 = (New-Object System.Xml.XmlNodeReader $XAML)
$Window                 = [Windows.Markup.XamlReader]::Load($Reader)
$XAML.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]") | ForEach-Object {Set-Variable -Name ($_.Name) -Value $Window.FindName($_.Name) -Scope Script}
$XAMLNodesVariableNames = $XAML.SelectNodes("//*[@*[contains(translate(name(.),'n','N'),'Name')]]").name

[System.Windows.RoutedEventHandler]$Script:CheckedEventHandler = `
{
    IF ($_.Source.Name -like 'rBtn*')
    {
        $txtInputFileRequired.text                 = "True"
        $txtRequireSPOSiteProcessingFirst.Text     = "False"
        $txtRequireMSOLProcessingFirst.Text        = "False"
        $cBoxSingleSeedFile.isChecked              = $False
        $txtEnforceSingleThread.text               = "False"
        $cBoxSPODestination.IsEnabled               = $false
        $txtMigrationBatchName.visibility = "Collapsed"
        $lblMigrationBatchName.visibility = "Collapsed"
        
        ForEach($WPFVariable in $XAMLNodesVariableNames)
        {
            if(($WPFVariable -like "rbtn*") -and ($WPFVariable -ne $_.Source.Name))
            {
                (get-variable $WPFVariable).value.isChecked = $False
            }
        }
        if($_.Source.Name -eq "rBtnExchangeOnline_v2_NewMigrationBatch")
        {
            $txtMigrationBatchName.visibility = "Visible"
            $lblMigrationBatchName.visibility = "Visible"
        }

        if($_.Source.Name -eq "rBtnSharePointOnline_GetFileACLs")
        {
            $cBoxSingleSeedFile.isChecked = "True"
        }
        if(($_.Source.Name -eq "rBtnSharePointOnline_A0_GetAllSPOSites") `
        -or ($_.Source.Name -eq "rBtnSharePointOnline_A0_GetAllPersonalSites"))

        {
            $txtInputFileRequired.text             = "False"
            $txtRequireSPOSiteProcessingFirst.Text = "True"
        }
        if($_.Source.Name -eq "rBtnMSOnlineService_GetMSOLUserSuffixes")
        {
            $txtInputFileRequired.text             = "False"
            $txtRequireMSOLProcessingFirst.Text    = "True"
        }
        if($_.Source.Name -eq "rBtnSharePointOnline_MoveSPOUserAndContent")
        {
            $cBoxSPODestination.IsEnabled = $true
        }
        if(($_.Source.Name -eq "rBtnMSOnlineService_GetMSOLAccountSKUs") `
            -or ($_.Source.Name -eq "rBtnExchangeOnline_GetAcceptedDomains") `
            -or ($_.Source.Name -eq "rBtnMSOnlineService_GetMSOLDomains") `
            -or ($_.Source.Name -eq "rBtnSharePointOnline_A1_GetAllPersonalSites") `
            -or ($_.Source.Name -eq "rBtnSharePointOnline_A1_GetAllSPOSites") `
            -or ($_.Source.Name -eq "rBtnMSGraph_GetOfficeActivationReport") `
            -or ($_.Source.Name -eq "rBtnMSGraph_GetYammerActivityReport") `
            -or ($_.Source.Name -eq "rBtnMSGraph_GetAllAADGroups"))
        {
            $txtInputFileRequired.text   = "False"
            $txtEnforceSingleThread.text = "True"
        }
        $txtExecutionmethod.Text                   = ($_.source.name) -replace ('rBtn','')
        $txtExecutionMethodName.Text               = $_.source.content
    }
    if($_.Source.Name -like "cBox*")
    {
        IF($_.source.name -eq "cBoxTargetEnvironment")
        {
            if($cboxTargetEnvironment.SelectedItem -eq "Microsoft 365")
            {
                $gridOnpremises.Visibility             = "Collapsed"
                $gridM365.Visibility                 = "Visible"
                $txtTargetEnvironmentSelection.text    = "gridM365"
                #$UserName                              = $txtM365AdminUN.text
                #if(!$UserName){PSCC-Refresh}
            }
            if($cboxTargetEnvironment.SelectedItem -eq "OnPremises")
            {
                $gridOnpremise.Visibility              = "Visible"
                $gridM365.Visibility                 = "Collapsed"
                $txtTargetEnvironmentSelection.text    = "gridOnpremises"
                #PSCC-Refresh
            }
        }

        if($_.Source.Name -like "cBoxOverride*")
        {
            $CustomFiles                 = New-Object System.Collections.ArrayList ###
            $cBoxOverride.items.clear()
            $CustomFiles                += ((Get-ChildItem -Path ".\" | Where-Object {($_.name -notlike "PSCC365*") -and ($_.Name -like "*.ps1")}).name)###
            $NumCustomFiles              = $CustomFiles.Count
            for ($i = 0; $i -le $NumCustomFiles; $i++)
            {
                $FoundFile               = $CustomFiles[$i]
                $cBoxOverride.items.Add("$FoundFile") | Out-Null
            }
        }
        if($_.Source.Name -like "cboxThreads*")
        {
            $ThreadBoxText               = $txtAppId.text
            if($ThreadBoxText -ne "")
            {
                if($ThreadAccountGroup -ne "")
                {
                    $cBoxThreads.items.clear()
                    For ($i=1; $i -le 40; $i++)
                    {
                        $cBoxThreads.items.Add("$i") | Out-Null
                    }
                }
            }
        }
        if($_.Source.Name -like "cBoxSelectConfig*")
        {
            $txtConfigBox_WasSelected.Text = "True"
            $CurrentDirectory               = (Resolve-Path .\).Path
            $ConfigFile = "$CurrentDirectory\Config.json"
            $ResolveWorkingPath             = Test-Path -Path $ConfigFile
            if($ResolveWorkingPath -eq $true )
            {
                $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json
                $ImportedConfigFile = $ImportedConfigFile | Sort-Object AppId
                $cBoxSelectConfig.Items.Clear()
                foreach($Tenant in $ImportedConfigFile)
                {
                    $cBoxSelectConfig.items.Add($Tenant.TenantName)
                }
            }
            Else
            {
                $cBoxSelectConfig.Items.Clear()
                $cBoxSelectConfig.items.Add("Configuration File Not Found") | Out-Null
            }
        }
    }
}
 
$cBoxSelectConfig.add_SelectionChanged(
{
    if($txtConfigBox_WasSelected.Text -eq "True")
    {
        $SelectedConfig = $cBoxSelectConfig.SelectedItem
        if($cBoxSelectConfig.SelectedItem -ne $null)
        {
            PSCC-LoadConfig -Actor "cBoxSelectConfig"
        }
    }
})

$MainGrid.AddHandler([System.Windows.Controls.RadioButton]::CheckedEvent, $CheckedEventHandler) 

#endregion
#=======================================================================================

#=======================================================================================
#region Set Default Values
#=======================================================================================

$host.ui.rawui.windowtitle           = "PowerShell Command Center Host PowerShell Session"
[datetime]$Today                     = Get-Date
$DatePickerExOStartDate.SelectedDate = Get-Date $Today.AddDays("-30") 
$DatePickerExOEndDate.SelectedDate   = Get-Date $Today
$TenantShort                         = ""
$TenantLong                          = "Office 365 Tenant Name"
$txtTargetEnvironmentSelection.text  = "gridM365"
$FileName                            = ""
$ExOnpremURI                         = $txtExOnpremURI.Text
$SleepThreshold                      = $txtSleep.Text
$ActiveThreshold                     = $txtThreshold.Text
$txtM365Tenant.Text                  = "Please first login to Office 365 by selecting `"Office 365 Global Admin`"."
$txtInputFile.Text                   = "Please select an input file"
$txtTenantReqs.text                  = "Not Connected"
$gridOnpremises.Visibility           = "Collapsed"
$gridM365.Visibility                 = "Visible"
$txtInputFileRequired.text           = "True"
$txtSPOAdminURL.text                 = "https://<tenantname>-admin.sharepoint.com/"
$txtSPOSource.Text                   = $txtSPOAdminURL.text
$txtExOURI.text                      = "https://outlook.office365.com/powershell-liveid"
$txtExchangeType.text                = "T2T"
$checkBoxT2TMigrations.IsChecked     = $true
$lblExOnpremURI.Content              = "Remote Tenant Name:"
$checkBoxConfirmExecution.IsChecked  = $false
$cBoxThreads.items.clear()
$cBoxThreads.items.Add("Connect to a target environment to determine threads") | Out-Null
$cboxTargetEnvironment.items.Add("Microsoft 365") | Out-Null
#$cboxTargetEnvironment.items.Add("OnPremises") | Out-Null
$cboxTargetEnvironment.SelectedItem = "Microsoft 365"

#endregion
#=======================================================================================

#=======================================================================================
#region Help Buttons
#=======================================================================================

$btnOpenTenantRootFolder.Add_Click(
{
    $TenantShort = $txtTenantReqs.text
    $CurrentDirectory               = (Resolve-Path .\).Path
    $FullOutputPath                 = "$CurrentDirectory\$TenantShort"
    explorer.exe $FullOutputPath
})

$btnDocumentationHelperWindow_GoToWiki.Add_Click(
{
    [system.Diagnostics.Process]::start($txtOpenURL.Text)
})
$btnDocumentationHelperWindow_Close.Add_Click(
{
    $gridDocumentationHelperWindow.visibility = "Collapsed"
})
$lblLinkExchangeOnline_ForceIncrementalSync.Add_MouseEnter(
{
    $lblLinkExchangeOnline_ForceIncrementalSync.Foreground                            = 'Purple'
})
$lblLinkExchangeOnline_ForceIncrementalSync.Add_MouseLeave(
{
    $lblLinkExchangeOnline_ForceIncrementalSync.Foreground                            = '#FF0A8AD2'
})
$lblLinkExchangeOnline_ForceIncrementalSync.Add_MouseLeftButtonUp(
{ 
    HelperData -WindowTitle "Force Incremental Sync" `
    -Info "Forces the move request to perform an incremental sync of the source mailbox." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FThe%20Exchange%20Online%20Module%20Support%2FMailbox%20Move%20Requests%2FForce%20Incremental%20Sync&pageId=877"
})
$lblLinkExchangeOnline_MailboxStatistics.Add_MouseEnter(
{
    $lblLinkExchangeOnline_MailboxStatistics.Foreground                            = 'Purple'
})
$lblLinkExchangeOnline_MailboxStatistics.Add_MouseLeave(
{
    $lblLinkExchangeOnline_MailboxStatistics.Foreground                            = '#FF0A8AD2'
})
$lblLinkExchangeOnline_MailboxStatistics.Add_MouseLeftButtonUp(
{ 
    HelperData -WindowTitle "Mailbox Statistics" `
    -Info "Captures the mailbox statistics for the designated primary and/or archive mailbox." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FThe%20Exchange%20Online%20Module%20Support%2FReporting%20Activities%2FMailbox%20Statistics&pageId=390"
})
$lblLinkExchangeOnline_MoveRequestStatistics.Add_MouseEnter(
{
    $lblLinkExchangeOnline_MoveRequestStatistics.Foreground                        = 'Purple'
})
$lblLinkExchangeOnline_MoveRequestStatistics.Add_MouseLeave(
{
    $lblLinkExchangeOnline_MoveRequestStatistics.Foreground                        = '#FF0A8AD2'
})
$lblLinkExchangeOnline_MoveRequestStatistics.Add_MouseLeftButtonUp(
{ 
    HelperData -WindowTitle "Move Request Statistics" `
    -Info "Captures the move request statistics (failures, percent complete and request status) for the designated mailboxes." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FThe%20Exchange%20Online%20Module%20Support%2FReporting%20Activities%2FMove%20Request%20Statistics&pageId=389"
})
$lblLinkExchangeOnline_MoveRequestPerformanceAndStatisticsDeepquery.Add_MouseEnter(
{
    $lblLinkExchangeOnline_MoveRequestPerformanceAndStatisticsDeepquery.Foreground = 'Purple'
})
$lblLinkExchangeOnline_MoveRequestPerformanceAndStatisticsDeepquery.Add_MouseLeave(
{
    $lblLinkExchangeOnline_MoveRequestPerformanceAndStatisticsDeepquery.Foreground = '#FF0A8AD2'
})
$lblLinkExchangeOnline_MoveRequestPerformanceAndStatisticsDeepquery.Add_MouseLeftButtonUp(
{ 
    HelperData -WindowTitle "Move Performance and Statistics Deep Query" `
    -Info "Captures a more detail view on the migration performance for the designated mailbox. Includes GB/hour, throttling frequency and pre-flight statistics." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FThe%20Exchange%20Online%20Module%20Support%2FReporting%20Activities%2FMove%20Request%20Performance%20and%20Statistics%20DeepQuery&pageId=392"
})
$lblLinkExchangeOnline_GetAcceptedDomains.Add_MouseEnter(
{
    $lblLinkExchangeOnline_GetAcceptedDomains.Foreground = 'Purple'
})
$lblLinkExchangeOnline_GetAcceptedDomains.Add_MouseLeave(
{
    $lblLinkExchangeOnline_GetAcceptedDomains.Foreground = '#FF0A8AD2'
})
$lblLinkExchangeOnline_GetAcceptedDomains.Add_MouseLeftButtonUp(
{ 
    HelperData -WindowTitle "Get Accepted Domains" `
    -Info "Captures all accepted domains in Exchange Online and queries all of the relivant DNS records pertaining to their use with Office 365." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FThe%20Exchange%20Online%20Module%20Support%2FReporting%20Activities%2FGet%20Accepted%20Domains&pageId=880"
})
$lblLinkMSGraph_ClientID.Add_MouseEnter(
{
    $lblLinkMSGraph_ClientID.Foreground                                            = 'Purple'
})
$lblLinkMSGraph_ClientID.Add_MouseLeave(
{
    $lblLinkMSGraph_ClientID.Foreground                                            = '#FF0A8AD2'
})
$lblLinkMSGraph_ClientID.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get Accepted Domains" `
    -Info "Captures all of the Accepted Domains registered in the tenant and provides an analysis of their DNS record configuration." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FAccounts%2C%20Software%20Prerequisites%20and%20Recommendations%2FMicrosoft%20Graph%20Prerequisites&pageId=653"
})
$lblLinkExchangeOnline_AdvancedMailboxStatistics.Add_MouseEnter(
{
    $lblLinkExchangeOnline_AdvancedMailboxStatistics.Foreground                    = 'Purple'
})
$lblLinkExchangeOnline_AdvancedMailboxStatistics.Add_MouseLeave(
{
    $lblLinkExchangeOnline_AdvancedMailboxStatistics.Foreground                    = '#FF0A8AD2'
})
$lblLinkExchangeOnline_AdvancedMailboxStatistics.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Part 1: Advanced Mailbox Statistics" `
    -Info "This is the first step in a two-step set of activities that capture the full profile of the designated mailbox and provides actionable data and insights into remediation activities. This activity captures in-depth mailbox statistics and should be run in the source tenant." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FThe%20Exchange%20Online%20Module%20Support%2FMailbox%20Migration%20Preparation%20Profile%2FPart%201%3A%20Advanced%20Mailbox%20Statistics&pageId=670"
})
$lblLinkExchangeOnline_AdvancedPreFlight.Add_MouseEnter(
{
    $lblLinkExchangeOnline_AdvancedPreFlight.Foreground                            = 'Purple'
})
$lblLinkExchangeOnline_AdvancedPreFlight.Add_MouseLeave(
{
    $lblLinkExchangeOnline_AdvancedPreFlight.Foreground                            = '#FF0A8AD2'
})
$lblLinkExchangeOnline_AdvancedPreFlight.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Part 2: Advanced Pre-Flight (WhatIf)"
    -Info "This is the second step in a two-step set of activities that capture the full profile of the designated mailbox and provides actionable data and insights into remediation activities. This activity captures in-depth pre-flight statistics and should be run in the target tenant."
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FThe%20Exchange%20Online%20Module%20Support%2FMailbox%20Migration%20Preparation%20Profile%2FPart%202%3A%20Advanced%20Pre%252DFlight%20(WhatIf)&pageId=671"
})
$lblLinkMSOnlineService_GetAllSuffixes.Add_MouseEnter(
{
    $lblLinkMSOnlineService_GetAllSuffixes.Foreground                              = 'Purple'
})
$lblLinkMSOnlineService_GetAllSuffixes.Add_MouseLeave(
{
    $lblLinkMSOnlineService_GetAllSuffixes.Foreground                              = '#FF0A8AD2'
})
$lblLinkMSOnlineService_GetAllSuffixes.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get All MSOLUser Suffixes" `
    -Info "Captures all msolusers in the connected tenant and outputs all primary and secondary SMTP addresses along with the recipient type. Idealy for understanding user disposition and the user of SMPT addresses across the tenant." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Online%20Module%20Support%2FGet%20All%20MSOLUser%20Suffixes&pageId=464"
})
$lblLinkMSOnlineService_UpdateFederatedToManaged.Add_MouseEnter(
{
    $lblLinkMSOnlineService_UpdateFederatedToManaged.Foreground                    = 'Purple'
})
$lblLinkMSOnlineService_UpdateFederatedToManaged.Add_MouseLeave(
{
    $lblLinkMSOnlineService_UpdateFederatedToManaged.Foreground                    = '#FF0A8AD2'
})
$lblLinkMSOnlineService_UpdateFederatedToManaged.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Update Federated UPN to Managed UPN" `
    -Info "Updates the UserPrincipalName of the designaged object. This scirpt is specifically designed to support mass-updates of UPN from a federated to non-federated name (or vice-versa)." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Online%20Module%20Support%2FUpdate%20Federated%20UPN%20to%20Managed%20UPN&pageId=572"
})
$lblLinkMSOnlineService_RemoveMSOLUser.Add_MouseEnter(
{
    $lblLinkMSOnlineService_RemoveMSOLUser.Foreground                              = 'Purple'
})
$lblLinkMSOnlineService_RemoveMSOLUser.Add_MouseLeave(
{
    $lblLinkMSOnlineService_RemoveMSOLUser.Foreground                              = '#FF0A8AD2'
})
$lblLinkMSOnlineService_RemoveMSOLUser.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Remove MSOLUser" `
    -Info "Deletes the designated MSOLUser and purges that identity from the recycle bin." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Online%20Module%20Support%2FRemove%20MSOLUser&pageId=573"
})
$lblLinkMSOnlineService_GetAssignedSKus.Add_MouseEnter(
{
    $lblLinkMSOnlineService_GetAssignedSKus.Foreground                             = 'Purple'
})
$lblLinkMSOnlineService_GetAssignedSKus.Add_MouseLeave(
{
    $lblLinkMSOnlineService_GetAssignedSKus.Foreground                             = '#FF0A8AD2'
})
$lblLinkMSOnlineService_GetAssignedSKus.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get Assigned Skus" `
    -Info "Captures all assigned skus for the designated user and outputs each sku to a new line." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Online%20Module%20Support%2FGet%20Assigned%20Skus&pageId=570"
})
$lblLinkMSOnlineService_GetTenantSubscriptions.Add_MouseEnter(
{
    $lblLinkMSOnlineService_GetTenantSubscriptions.Foreground                      = 'Purple'
})
$lblLinkMSOnlineService_GetTenantSubscriptions.Add_MouseLeave(
{
    $lblLinkMSOnlineService_GetTenantSubscriptions.Foreground                      = '#FF0A8AD2'
})
$lblLinkMSOnlineService_GetTenantSubscriptions.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get Tenant Subscriptions" `
    -Info "Captures all available SKUs in the tenant and report back important statistics about each of them." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Online%20Module%20Support%2FGet%20Tenant%20Subscriptions&pageId=879"
})
$lblLinkMSOnlineService_GetMSOLDomains.Add_MouseEnter(
{
    $lblLinkMSOnlineService_GetMSOLDomains.Foreground                      = 'Purple'
})
$lblLinkMSOnlineService_GetMSOLDomains.Add_MouseLeave(
{
    $lblLinkMSOnlineService_GetMSOLDomains.Foreground                      = '#FF0A8AD2'
})
$lblLinkMSOnlineService_GetMSOLDomains.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get MSOL Domains" `
    -Info "Captures all of the MSOL Domains registered in the tenant and provides an analysis of their DNS record configuration." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Online%20Module%20Support%2FGet%20MSOL%20Domains&pageId=882"
})
$lblLinkSharePointOnline_A0_GetAllSites.Add_MouseEnter(
{
    $lblLinkSharePointOnline_A0_GetAllSites.Foreground                             = 'Purple'
})
$lblLinkSharePointOnline_A0_GetAllSites.Add_MouseLeave(
{
    $lblLinkSharePointOnline_A0_GetAllSites.Foreground                             = '#FF0A8AD2'
})
$lblLinkSharePointOnline_A0_GetAllSites.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "P1: Get Sites, Sub-sites and Personal Sites (CSOM)" `
    -Info "The first step in a two-step process for performing OneDrive for Business personal site assessments. This will capture a sites, sub-sites and personal sites in SharePoint." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Assessment%2FGet%20Sites%2C%20Sub%252Dsites%20and%20Personal%20Sites%20(CSOM)&pageId=405"
})
$lblLinkSharePointOnline_A2_GetSiteItemInformation.Add_MouseEnter(
{
    $lblLinkSharePointOnline_A2_GetSiteItemInformation.Foreground                  = 'Purple'
})
$lblLinkSharePointOnline_A2_GetSiteItemInformation.Add_MouseLeave(
{
    $lblLinkSharePointOnline_A2_GetSiteItemInformation.Foreground                  = '#FF0A8AD2'
})
$lblLinkSharePointOnline_A2_GetSiteItemInformation.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "P2: Get Site Item-level Data (CSOM)" `
    -Info "The second step in a two-step process for performing OneDrive for Business personal site assessments. This will perform an individual, item-level assessment of each deisgnated site." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Assessment%2FGet%20Site%20Item%252DLevel%20Data%20(CSOM)&pageId=407"
})
$lblLinkSharePointOnline_ProvisionPersonalSite.Add_MouseEnter(
{
    $lblLinkSharePointOnline_ProvisionPersonalSite.Foreground                      = 'Purple'
})
$lblLinkSharePointOnline_ProvisionPersonalSite.Add_MouseLeave(
{
    $lblLinkSharePointOnline_ProvisionPersonalSite.Foreground                      = '#FF0A8AD2'
})
$lblLinkSharePointOnline_ProvisionPersonalSite.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Provision Personal Site (CSOM)" `
    -Info "Calls this profile creation service to provision the designated users personal site." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Tools%2FProvision%20Personal%20Site%20(CSOM)&pageId=427"
})
$lblLinkSharePointOnline_GetUsersProfile.Add_MouseEnter(
{
    $lblLinkSharePointOnline_GetUsersProfile.Foreground                            = 'Purple'
})
$lblLinkSharePointOnline_GetUsersProfile.Add_MouseLeave(
{
    $lblLinkSharePointOnline_GetUsersProfile.Foreground                            = '#FF0A8AD2'
})
$lblLinkSharePointOnline_GetUsersProfile.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get User's Profile (CSOM)" `
    -Info "Queries the user profile service to capture the designated users SharePoint profile data. The output includes the personal site provisioning status and the personal site URL." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Tools%2FGet%20User%27s%20Profile%20(CSOM)&pageId=428"
})
$lblLinkSharePointOnline_SetSite_ReadOnly.Add_MouseEnter(
{
    $lblLinkSharePointOnline_SetSite_ReadOnly.Foreground                           = 'Purple'
})
$lblLinkSharePointOnline_SetSite_ReadOnly.Add_MouseLeave(
{
    $lblLinkSharePointOnline_SetSite_ReadOnly.Foreground                           = '#FF0A8AD2'
})
$lblLinkSharePointOnline_SetSite_ReadOnly.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Set Site(s) as Read-Only (SPOCmdlet)" `
    -Info "Sets the designated site as 'read-only' and prevents new content from beign created." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Tools%2FSet%20Site(s)%20as%20Read%252Donly%20(SPOCmdlet)&pageId=429"
})
$lblLinkSharePointOnline_SetSiteCollectionAdmin.Add_MouseEnter(
{
    $lblLinkSharePointOnline_SetSiteCollectionAdmin.Foreground                     = 'Purple'
})
$lblLinkSharePointOnline_SetSiteCollectionAdmin.Add_MouseLeave(
{
    $lblLinkSharePointOnline_SetSiteCollectionAdmin.Foreground                     = '#FF0A8AD2'
})
$lblLinkSharePointOnline_SetSiteCollectionAdmin.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Set Site Collection Admin (SPOCmdlet)" `
    -Info "Sets the selected thread group (from the thread prefix menu) as site collection administrators to the designated site." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Tools%2FSet%20Site%20Collection%20Admin%20(SPOCmdlet)&pageId=430"
})
$lblLinkSharePointOnline_RemoveSiteCollectionAdmin.Add_MouseEnter(
{
    $lblLinkSharePointOnline_RemoveSiteCollectionAdmin.Foreground                     = 'Purple'
})
$lblLinkSharePointOnline_RemoveSiteCollectionAdmin.Add_MouseLeave(
{
    $lblLinkSharePointOnline_RemoveSiteCollectionAdmin.Foreground                     = '#FF0A8AD2'
})
$lblLinkSharePointOnline_RemoveSiteCollectionAdmin.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Remove Site Collection Admin (SPOCmdlet)" `
    -Info "Removes the selected thread group (from the thread prefix menu) as site collection administrators to the designated site." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Tools%2FSet%20Site%20Collection%20Admin%20(SPOCmdlet)&pageId=430"
})
$lblLinkSharePointOnline_MoveSPOUserAndContent.Add_MouseEnter(
{
    $lblLinkSharePointOnline_MoveSPOUserAndContent.Foreground                     = 'Purple'
})
$lblLinkSharePointOnline_MoveSPOUserAndContent.Add_MouseLeave(
{
    $lblLinkSharePointOnline_MoveSPOUserAndContent.Foreground                     = '#FF0A8AD2'
})
$lblLinkSharePointOnline_MoveSPOUserAndContent.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Remove Site Collection Admin (SPOCmdlet)" `
    -Info "Moves the user and their OneDrive content to the target GEO. SPO Admin Url must be associated with the users current GEO and the Destination GEO populated." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FSharePoint%20Online%20Module%20Support%2FOneDrive%20for%20Business%20Tools%2FSet%20Site%20Collection%20Admin%20(SPOCmdlet)&pageId=430"
})
$lblLinkSharePointOnline_DestinationGEO.Add_MouseEnter(
{
    $lblLinkSharePointOnline_DestinationGEO.Foreground                     = 'Purple'
})
$lblLinkSharePointOnline_DestinationGEO.Add_MouseLeave(
{
    $lblLinkSharePointOnline_DestinationGEO.Foreground                     = '#FF0A8AD2'
})
$lblLinkSharePointOnline_DestinationGEO.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Office 365 Geographies" `
    -Info "This is a list of all GEOs available for Office 365. This is droped down is selectable when ""Move User and Content"" is selected. See the Wiki button to understand more." `
    -Url "https://docs.microsoft.com/en-us/office365/enterprise/office-365-multi-geo"
})
$lblLinkSharePointOnline_SourceTenant.Add_MouseEnter(
{
    $lblLinkSharePointOnline_SourceTenant.Foreground                     = 'Purple'
})
$lblLinkSharePointOnline_SourceTenant.Add_MouseLeave(
{
    $lblLinkSharePointOnline_SourceTenant.Foreground                     = '#FF0A8AD2'
})
$lblLinkSharePointOnline_SourceTenant.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Office 365 Source GEO Tenant" `
    -Info "This is the URL of the tenant that PSCC will connect to for execution purposes. If doing multi-geo activities, this should be the GEO where the user currently resides. If this URL is incorrect, please go to ""Settings"" to change it" `
    -Url "https://docs.microsoft.com/en-us/office365/enterprise/office-365-multi-geo"
})
$lblLinkSkypeTeams_InvokeMMS.Add_MouseEnter(
{
    $lblLinkSkypeTeams_InvokeMMS.Foreground                     = 'Purple'
})
$lblLinkSkypeTeams_InvokeMMS.Add_MouseLeave(
{
    $lblLinkSkypeTeams_InvokeMMS.Foreground                     = '#FF0A8AD2'
})
$lblLinkSkypeTeams_InvokeMMS.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Invoke Meeting Migration Service (MMS)" `
    -Info "Queues the target user for the Skype / Teams meeting migration service. This updates the meetings associated with the users legacy tenant to point to the new tenant." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FInvoke%20Meeting%20Migration%20Service%20(MMS)&pageId=886"
})
$lblLinkMSGraph_GetUserDevices.Add_MouseEnter(
{
    $lblLinkMSGraph_GetUserDevices.Foreground                     = 'Purple'
})
$lblLinkMSGraph_GetUserDevices.Add_MouseLeave(
{
    $lblLinkMSGraph_GetUserDevices.Foreground                     = '#FF0A8AD2'
})
$lblLinkMSGraph_GetUserDevices.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get User Devices (Intune)" `
    -Info "Captures all devices associated with the user in Intune." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Graph%2FGet%20User%20Devices%20(Intune)&pageId=889"
})
$lblLinkMSGraph_GetAllAADGroups.Add_MouseEnter(
{
    $lblLinkMSGraph_GetAllAADGroups.Foreground                     = 'Purple'
})
$lblLinkMSGraph_GetAllAADGroups.Add_MouseLeave(
{
    $lblLinkMSGraph_GetAllAADGroups.Foreground                     = '#FF0A8AD2'
})
$lblLinkMSGraph_GetAllAADGroups.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get All AAD Groups" `
    -Info "Captures all devices associated with the user in Intune." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Graph%2FGet%20All%20Groups%20in%20AAD&pageId=890"
})
$lblLinkMSGraph_GetOfficeActivationReport.Add_MouseEnter(
{
    $lblLinkMSGraph_GetOfficeActivationReport.Foreground                     = 'Purple'
})
$lblLinkMSGraph_GetOfficeActivationReport.Add_MouseLeave(
{
    $lblLinkMSGraph_GetOfficeActivationReport.Foreground                     = '#FF0A8AD2'
})
$lblLinkMSGraph_GetOfficeActivationReport.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get Office Activaion Report" `
    -Info "Queries the Office 365 reporting service to capture all Office activations against the target tenant." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Graph%2FGet%20Office%20Activations&pageId=891"
})
$lblLinkMSGraph_GetYammerActivityReports.Add_MouseEnter(
{
    $lblLinkMSGraph_GetYammerActivityReports.Foreground                     = 'Purple'
})
$lblLinkMSGraph_GetYammerActivityReports.Add_MouseLeave(
{
    $lblLinkMSGraph_GetYammerActivityReports.Foreground                     = '#FF0A8AD2'
})
$lblLinkMSGraph_GetYammerActivityReports.Add_MouseLeftButtonDown(
{ 
    HelperData -WindowTitle "Get Yammer Activity Reports" `
    -Info "Captures the number of unique users using Yammer and the amount of activity generated across the organization." `
    -Url "https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FUnderstanding%20the%20Modules%2FMicrosoft%20Graph%2FGet%20Yammer%20Activity%20Report&pageId=892"
})

#endregion
#=======================================================================================

#=======================================================================================
#region Main Window
#=======================================================================================

$btnClose.Add_Click(
{
    [System.GC]::Collect()
    $Window.Close()
}) 
$btnStatusWindow.Add_Click(
{
    $StatusWindowVisibility = $gridStatusWindow.Visibility
    if($StatusWindowVisibility -eq "Collapsed")
    {
        $gridStatusWindow.Visibility = "Visible"
    }
    if($StatusWindowVisibility -eq "Visible")
    {
        $gridStatusWindow.visibility = "Collapsed"
    }
}) 
$btnMin.Add_Click(
{
    $Window.WindowState = "Minimized"
})
$Window.Add_MouseLeftButtonDown(
{
    $Window.DragMove()
})
$btnAbout.Add_Click(
{
    [system.Diagnostics.Process]::start('https://servicescode.visualstudio.com/IP%20-%20Mergers%20Acquisitions%20Divestitures/_wiki/wikis/IP---Microsoft-365-Tenant-Migrations.wiki?wikiVersion=GBwikiMaster&pagePath=%2FPowerShell%20Command%20Center%20%252D%20Delivery%20Guidance%2FHow%20to%20get%20Support&pageId=347')
})
$btnInputFile.Add_Click(
{
    PSCC-ImportCSV_XML
})
$btnStart.Add_Click(
{
    PSCC-Start
})
$btnCancel.Add_Click(
{
    $host.ui.rawui.windowtitle = "Windows PowerShell";[System.GC]::Collect();$Window.Close()
})
$btnSourceMig.Add_Click(
{
    PSCC-SourceMigAccount
})
$checkBoxT2TMigrations.Add_Checked(
{
    $lblExOnpremURI.Content   = "Remote Tenant Name:"
    $txtExchangeType.text = "T2T"
    $btnSourceMig.IsEnabled                = $false
    $btnSourceMig.visibility = "Collapsed"
})
$checkBoxT2TMigrations.Add_UnChecked(
{
    $lblExOnpremURI.Content = "On-Premises Exchange URI:"
    $txtExchangeType.text = "Onpremises"
    $btnSourceMig.IsEnabled                = $True
    $btnSourceMig.Visibility = "Visible"
})
$checkBoxOverride.Add_Checked(
{
    $txtInputFileRequired.text                 = "True"
    $txtRequireSPOSiteProcessingFirst.Text     = "False"
    $txtRequireMSOLProcessingFirst.Text        = "False"
    $cBoxSingleSeedFile.isChecked              = $False
    $txtEnforceSingleThread.text               = "False"
    ForEach($WPFVariable in $XAMLNodesVariableNames)
    {
        if(($WPFVariable -like "rbtn*") -and ($WPFVariable -ne $_.Source.Name))
        {
            (get-variable $WPFVariable).value.isChecked = $False
        }
    }
})

#endregion
#=======================================================================================

#=======================================================================================
#region Configuration Manager
#=======================================================================================

#=======================================================================================
#region Configuration Manager -> Main Window Config Activities
#=======================================================================================

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager -> Main Window Activities ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigManagerHideShow.Add_Click(
{
    $ConfigManageVisibility = $gridConfigWindow.Visibility
    if($ConfigManageVisibility -eq "Collapsed")
    {
        $CurrentDirectory               = (Resolve-Path .\).Path
        $ConfigFile = "$CurrentDirectory\Config.json"
        $ResolveWorkingPath             = Test-Path -Path $ConfigFile
        if($ResolveWorkingPath -eq $true )
        {
            $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json 
            $datagridConfigWindow.Items.Clear()
            $ImportedConfigFile = $ImportedConfigFile | Sort-Object AppId
            foreach($Tenant in $ImportedConfigFile)
            {
                $datagridConfigWindow.AddChild([pscustomobject]@{
                    AppId=$Tenant.AppId
                    TenantName=$Tenant.TenantName
                })
            }
        }
    }
    if($ConfigManageVisibility -eq "Collapsed")
    {
        $gridConfigWindow.Visibility = "Visible"
    }
    if($ConfigManageVisibility -eq "Visible")
    {
        $gridConfigWindow.visibility = "Collapsed"
    }
})


#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Window - 'Close' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_Close.Add_Click(
{
    $gridConfigWindow.visibility = "Collapsed"
})

#endregion
#=======================================================================================

#=======================================================================================
#region Configuration Manager -> New Config Activities
#=======================================================================================

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Window - 'New' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_New.Add_Click(
{
    $txtConfigWindow_NewSave_Name.Text = $null
    if(($txtBlockConfigWindow_NewSave_Status.Text -like "*Connected*") -or ($txtBlockConfigWindow_NewSave_Status.Text -eq "Disconnected: Invalid Credentials"))
    {
        $txtBlockConfigWindow_NewSave_Status.Text = "[not connected]"
    }
    $gridConfigWindow_NewSave.Visibility = "Visible"
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager New Config Save Window - 'Close' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_NewSave_Cancel.Add_Click(
{
    $gridConfigWindow_NewSave.visibility = "Collapsed"
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager New Config Save Window - 'Connect' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_NewSave_Connect.Add_Click(
{
    PSCC-ConnectMSOL -Actor "NewConfigWindow"
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager New Config Save Window - 'Save' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_NewSave_Save.Add_Click(
{
    if(($txtConfigWindow_NewSave_Name.text -eq $null) -or ($txtConfigWindow_NewSave_Name.text -eq "") -or ($txtConfigWindow_NewSave_Name -eq " "))
    {
        $null #need to update to do something
    }
    $FoundDuplicateAppId = $false
    $CurrentDirectory               = (Resolve-Path .\).Path
    $ConfigFile = "$CurrentDirectory\Config.json"
    $ResolveWorkingPath             = Test-Path -Path $ConfigFile
    if($ResolveWorkingPath -eq $true )
    {
        $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json 
        foreach($Tenant in $ImportedConfigFile)
        {
            if($Tenant.AppId -eq $txtConfigWindow_NewSave_AppId.Text)
            {
                $FoundDuplicateAppId = $true
            }
        }
        if($FoundDuplicateAppId -eq $true)
        {
            $txtConfigWindow_SaveAppIdWindow_Name.text = $txtM365Tenant.Text
            $gridConfigWindow_SaveAppIdWindow_ExistsWindow.Visibility = "Visible" #if save reference name exists, pop up exists window.
        }
        else
        {
            $txtConfigAppId.Text = $txtConfigWindow_NewSave_AppId.text
            $txtAppId.Text = $txtConfigAppId.Text
            $JSONConfig = PSCC-GetConfigAsJSON
            $lblTitle.Content = "PowerShell Command Center ($($txtConfigWindow_NewSave_Name.text))"
            $NewConfigFile = @()
            $NewConfigFile += $ImportedConfigFile
            $NewConfigFile += $JSONConfig | ConvertFrom-Json
            $NewConfigFile | ConvertTo-Json -Depth 5| Out-File $ConfigFile
            $datagridConfigWindow.Items.Clear()
            $NewConfigFile = $NewConfigFile | Sort-Object AppId
            foreach($Tenant in $NewConfigFile)
            {
                $datagridConfigWindow.AddChild([pscustomobject]@{
                    AppId = $Tenant.AppId;TenantName = $Tenant.TenantName
                })
            }
            $gridConfigWindow_NewSave.visibility = "Collapsed"
            }
        }
    else
    {
        $txtConfigAppId.Text = $txtConfigWindow_NewSave_AppId.text
        $txtAppId.Text = $txtConfigAppId.Text

        Write-Host "Creating new Connetion Configuration (Config.json) file" -ForegroundColor Yellow
        $JSONConfig = PSCC-GetConfigAsJSON
        $lblTitle.Content = "PowerShell Command Center ($($txtConfigWindow_NewSave_Name.text))"
        $NewConfigFile = $JSONConfig | ConvertFrom-Json
        $NewConfigFile | ConvertTo-Json -Depth 5| Out-File $ConfigFile
        $gridConfigWindow_SaveAppIdWindow_ExistsWindow.visibility = "Collapsed"
        $datagridConfigWindow.Items.Clear()
        $NewConfigFile = $NewConfigFile | Sort-Object AppId
        foreach($Tenant in $NewConfigFile)
        {
            $datagridConfigWindow.AddChild([pscustomobject]@{
                AppId = $Tenant.AppId;TenantName = $Tenant.TenantName
            })
        }
        $gridConfigWindow_SaveAppIdWindow.visibility = "Collapsed"
        if($txtConfigWindow_NewSave_Name.Text -ne $null)
        {
            $lblTitle.Content               = "PowerShell Command Center ($($txtConfigWindow_NewSave_Name.Text))"
        }
        $gridConfigWindow_NewSave.visibility = "Collapsed"
        $txtConfigWindow_NewSave_Name.text = $null
    }
})

#endregion
#=======================================================================================

#=======================================================================================
#region Configuration Manager -> Load Config Activities
#=======================================================================================

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Window - 'Load' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_Load.Add_Click(
{
    if($datagridConfigWindow.SelectedValue.AppId -ne $null)
    {
        $txtM365AdminPWD.text = $null
        $txtConfigBox_WasSelected.text = "false"
        $cBoxSelectConfig.SelectedItem = $null
        $CurrentDirectory               = (Resolve-Path .\).Path
        $ConfigFile = "$CurrentDirectory\Config.json"
        $ResolveWorkingPath             = Test-Path -Path $ConfigFile
        if($ResolveWorkingPath -eq $true )
        {
            $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json
            $ImportedConfigFile = $ImportedConfigFile | Sort-Object AppId
            $cBoxSelectConfig.Items.Clear()
            foreach($Tenant in $ImportedConfigFile)
            {
                $cBoxSelectConfig.items.Add($Tenant.AppId)
            }
        }
        Else
        {
            $cBoxSelectConfig.Items.Clear()
            $cBoxSelectConfig.items.Add("Configuration File Not Found") | Out-Null
        }
        $cBoxSelectConfig.SelectedItem = $datagridConfigWindow.SelectedValue.AppId
        PSCC-LoadConfig -Actor "btnConfigWindow_Load"
    }
})

#endregion
#=======================================================================================

#=======================================================================================
#region Configuration Manager -> Save Config Activities
#=======================================================================================

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Window - 'Save' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_Save.Add_Click(
{
    $gridConfigWindow_SaveAppIdWindow.Visibility = "Visible"
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Save Reference Name Window - 'Cancel' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_SaveAppIdWindow_Cancel.Add_Click(
{
    $gridConfigWindow_SaveAppIdWindow.visibility = "Collapsed"
    $txtConfigWindow_SaveAppIdWindow_Name.text = $null
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Save Reference Name Window - 'Save' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_SaveAppIdWindow_Save.Add_Click(
{
    $FoundDuplicateAppId = $false
    $CurrentDirectory               = (Resolve-Path .\).Path
    $ConfigFile = "$CurrentDirectory\Config.json"
    $ResolveWorkingPath             = Test-Path -Path $ConfigFile
    if($ResolveWorkingPath -eq $true )
    {
        $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json 
        $gridConfigWindow_SaveAppIdWindow.Visibility = "Visible"
        foreach($Tenant in $ImportedConfigFile)
        {
            if($Tenant.TenantName -eq $txtConfigWindow_SaveAppIdWindow_Name.Text)
            {
                $FoundDuplicateAppId = $true
            }
        }
        if($FoundDuplicateAppId -eq $true)
        {
            $gridConfigWindow_SaveAppIdWindow_ExistsWindow.Visibility = "Visible"
        }
        else
        {
            $txtM365Tenant.Text = $txtConfigWindow_SaveAppIdWindow_Name.text
            $JSONConfig = PSCC-GetConfigAsJSON
            $NewConfigFile = @()
            $NewConfigFile += $ImportedConfigFile
            $NewConfigFile += $JSONConfig | ConvertFrom-Json
            $NewConfigFile | ConvertTo-Json -Depth 5| Out-File $ConfigFile
            $gridConfigWindow_SaveAppIdWindow.visibility = "Collapsed"
            $gridConfigWindow_SaveAppIdWindow_ExistsWindow.visibility = "Collapsed"
            $datagridConfigWindow.Items.Clear()
            $NewConfigFile = $NewConfigFile | Sort-Object AppId
            foreach($Tenant in $NewConfigFile)
            {
                $datagridConfigWindow.AddChild([pscustomobject]@{
                    AppId=$Tenant.AppId;TenantName=$Tenant.TenantName
                })
            }
        }
    }
    else
    {
        $txtConfigAppId.Text = $txtConfigWindow_SaveAppIdWindow_Name.text
        Write-Host "Creating new Config.json file" -ForegroundColor Yellow
        $JSONConfig = PSCC-GetConfigAsJSON
        $NewConfigFile = $JSONConfig | ConvertFrom-Json
        $NewConfigFile | ConvertTo-Json -Depth 5| Out-File $ConfigFile
        $gridConfigWindow_SaveAppIdWindow_ExistsWindow.visibility = "Collapsed"
        $datagridConfigWindow.Items.Clear()
        $NewConfigFile = $NewConfigFile | Sort-Object AppId
        foreach($Tenant in $NewConfigFile)
        {
            $datagridConfigWindow.AddChild([pscustomobject]@{
                AppId=$Tenant.AppId;TenantName=$Tenant.TenantName
            })
        }
        $gridConfigWindow_SaveAppIdWindow.visibility = "Collapsed"
        $txtConfigWindow_SaveAppIdWindow_Name.text = $null
    }
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Save Reference Name Exists Window - 'Cancel' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_SaveAppIdWindow_ExistsWindow_Cancel.Add_Click(
{
    $gridConfigWindow_SaveAppIdWindow_ExistsWindow.visibility = "Collapsed"
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Save Reference Name Exists Window - 'Overwrite' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_SaveAppIdWindow_ExistsWindow_Overwrite.Add_Click(
{
    $CurrentDirectory               = (Resolve-Path .\).Path
    $ConfigFile = "$CurrentDirectory\Config.json"
    $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json 
    $txtM365Tenant.Text = $txtConfigWindow_SaveAppIdWindow_Name.text
    $RedactedConfigFile = @()
    foreach($Tenant in $ImportedConfigFile)
    {
        if($Tenant.TenantName -ne $txtConfigWindow_SaveAppIdWindow_Name.Text)
        {
            $RedactedConfigFile += $Tenant
        }
    }
    $JSONConfig = PSCC-GetConfigAsJSON
    $lblTitle.Content = "PowerShell Command Center ($($txtConfigWindow_SaveAppIdWindow_Name.text) | $($txtTenantReqs.text))"
    $NewConfigFile = @()
    $NewConfigFile += $RedactedConfigFile
    $NewConfigFile += $JSONConfig | ConvertFrom-Json
    $NewConfigFile | ConvertTo-Json -Depth 5| Out-File $ConfigFile
    if($gridConfigWindow_SaveAppIdWindow.Visibility -eq "Visible")
    {
        $gridConfigWindow_SaveAppIdWindow.visibility = "Collapsed"
    }
    if($gridConfigWindow_NewSave.Visibility -eq "Visible")
    {
        $gridConfigWindow_NewSave.visibility = "Collapsed"
    }
    $gridConfigWindow_SaveAppIdWindow_ExistsWindow.visibility = "Collapsed"
    $gridConfigWindow_NewSave.visibility = "Collapsed"
    $datagridConfigWindow.Items.Clear()
    $NewConfigFile = $NewConfigFile | Sort-Object AppId
    foreach($Tenant in $NewConfigFile)
    {
        $datagridConfigWindow.AddChild([pscustomobject]@{
            AppId=$Tenant.AppId
            TenantName=$Tenant.TenantName
        })
    }
    if($txtConfigAppId.Text -ne $null)
    {
        $lblTitle.Content               = "PowerShell Command Center ($($txtConfigAppId.Text) | $($txtTenantReqs.text))"
    }
    $txtConfigWindow_SaveAppIdWindow_Name.text = $null
})

#endregion
#=======================================================================================

#=======================================================================================
#region Configuration Manager -> Delete Config Activities
#=======================================================================================

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Window - 'Delete' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_Delete.Add_Click(
{
    if($datagridConfigWindow.SelectedValue.AppId -ne $null)
    {
        $txtBlockConfigWindow_DeleteWindow_Info.Text = "Are you sure you want to delete: $($datagridConfigWindow.SelectedValue.AppId)"
        $gridConfigWindow_DeleteWindow.Visibility = "Visible"
    }
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Delete Config Window - 'Cancel' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_DeleteWindow_Cancel.Add_Click(
{
    $gridConfigWindow_DeleteWindow.visibility = "Collapsed"
})

#▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼ Configuration Manager Delete Config Window - 'Okay' Button ▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼▼
$btnConfigWindow_DeleteWindow_Okay.Add_Click(
{
    $CurrentDirectory               = (Resolve-Path .\).Path
    $ConfigFile = "$CurrentDirectory\Config.json"
    $ImportedConfigFile = Get-Content -Raw $ConfigFile | ConvertFrom-Json 
    $RedactedConfigFile = @()
    foreach($Tenant in $ImportedConfigFile)
    {
        if($Tenant.AppId -ne $datagridConfigWindow.SelectedValue.AppId)
        {
            $RedactedConfigFile += $Tenant
        }
    }
    $RedactedConfigFile | ConvertTo-Json -Depth 5 | Out-File $ConfigFile
    $gridConfigWindow_DeleteWindow.visibility = "Collapsed"
    $datagridConfigWindow.Items.Clear()
    $RedactedConfigFile = $RedactedConfigFile | Sort-Object AppId
    foreach($Tenant in $RedactedConfigFile)
    {
        $datagridConfigWindow.AddChild([pscustomobject]@{
            AppId=$Tenant.AppId
            TenantName=$Tenant.TenantName
        })
    }
})

#endregion
#=======================================================================================

#endregion
#=======================================================================================

#=======================================================================================
#region Settings Window
#=======================================================================================

$btnSettings.Add_Click(
{
    $gridSettings.visibility = "Visible"
})
$btnSettings_Okay.Add_Click(
{
    $gridSettings.visibility = "Collapsed"
    $txtSPOSource.text = $txtSPOAdminURL.text
})
$cBoxSettings_EnableCustomScriptTab.Add_Checked(
{
    $tabitemM365CustomScripts.Visibility = "Visible"
})
$cBoxSettings_EnableCustomScriptTab.Add_UnChecked(
{
    $tabitemM365CustomScripts.Visibility = "Collapsed"
})

#endregion
#=======================================================================================

#endregion
#=======================================================================================

#=======================================================================================
#region Start Execution
#=======================================================================================

$btndConfirmExecutionWindow_Cancel.Add_Click(
{
    $gridConfirmExecutionWindow.visibility = "Collapsed"
    $checkBoxConfirmExecution.IsChecked     = $false
})
$btndConfirmExecutionWindow_Confirm.Add_Click(
{
    $gridConfirmExecutionWindow.visibility = "Collapsed"
    PSCC-Start
    $gridConfirmExecutionWindow.visibility = "Collapsed"
})
$checkBoxConfirmExecution.Add_Checked(
{
    $btndConfirmExecutionWindow_Confirm.IsEnabled = $true
})
$checkBoxConfirmExecution.Add_UnChecked(
{
    $btndConfirmExecutionWindow_Confirm.IsEnabled = $false
})
$btnStartFailureWindow_Cancel.Add_Click(
{
    $gridStartFailureWindow.visibility = "Collapsed"
})

#endregion
#=======================================================================================

#=======================================================================================
#region Check Prerequisites
#=======================================================================================

UnblockFiles
CheckPSPreReqs
CheckMSOPreReqs
CheckSPOPreReqs 
CheckS4BOPreReqs
#CheckAIPService
CheckCredManPreReqs
CheckConfigfile

#endregion
#=======================================================================================

#=======================================================================================
#region CLEANUP
#=======================================================================================

$Window.Showdialog() | Out-Null
$reader.Dispose()

#endregion
#=======================================================================================