$server = "VMADS003.APEXGROUP.CLOUD"
$sourceOU = "OU=Cloud Synced,OU=Application Security Groups,OU=Citrix Permissions,DC=APEXGROUP,DC=CLOUD"
$targetOU = "OU=Prod CloudPC,OU=Application Security Groups,OU=Windows365 Permissions,DC=APEXGROUP,DC=CLOUD"
$sourceGroups = Get-ADGroup -Filter * -SearchBase $sourceOU -Server $server 

$errorsCreatingGroups = @()
$count = 0
$groupsCreated = @()
$groupsNotCreated = @()
$errorsMembers = @() 

foreach ($group in $sourceGroups) {
    $count ++
    if ($count % 10 -eq 0) {
        Write-Host "Processing group number $($count) of $($sourceGroups.count)" -ForegroundColor Green
    }
    # First we create the group
    $sourceGroupName = $group.Name
    $newGroupName = $sourceGroupName -replace "CTX", "W365"
    if ($null -ne $group.description) {
        $newGroupDescription = $group.Description
    }
    if ($null -ne $group.DisplayName) {
        $newGroupDisplayName = $group.DisplayName
    }
    $newGroupCategory = $group.GroupCategory
    $newGroupScope = $group.GroupScope
    if ($null -ne $group.ManagedBy) {
        $newGroupManagedBy = $group.ManagedBy
    }
    $newGroupSamAccountName = $newGroupName
    $params = @{
        Name           = $newGroupName
        Description    = $newGroupDescription
        DisplayName    = $newGroupDisplayName
        GroupCategory  = $newGroupCategory
        GroupScope     = $newGroupScope
        ManagedBy      = $newGroupManagedBy
        Path           = $targetOU
        SamAccountName = $newGroupSamAccountName
        Server         = $server  
    }
    try {
        New-ADGroup @params
        $groupsCreated += $newGroupName
        Start-Sleep -Milliseconds 200
    }
    catch {
        $a = @{
            CommandError   = $_
            GroupNameError = $group.Name
        }
        $errorsCreatingGroups += $a
    }
    # Here we wait for the new group creation
    $counterCreation = 0
    $newGroupObject = Get-ADGroup -Filter { name -eq $newGroupName } -Server $server -ErrorAction SilentlyContinue
    while ($null -eq $newGroupObject -and $counterCreation -lt 10) {
        Write-Host "New group still not created. Trying again in 18 seconds. Try number $($counter) out of 10" -ForegroundColor Red
        Start-Sleep 18
        $counterCreation++
        $newGoupObject = Get-ADGroup -Filter { name -eq $newGroupName } -Server $server -ErrorAction SilentlyContinue
        if ($counterCreation -eq '10') {
            $groupsNotCreated += $newGroupName
            Write-Host "Group is not created successfully. Moving to the next one." -ForegroundColor Red
        }
    }
    # After the group is created, we add the members
    ## Enumerating the members
    $members = Get-ADGroupMember -Identity $group
    $newMembers = @()
    foreach ($member in $members) {
        if ($member.ObjectClass -eq 'group') {
            $groupMembers = Get-ADGroup -Identity $member.name -Properties member | select -ExpandProperty member
            $newMembers += $groupMembers
        }
        else {
            $newMembers += $member
        }
    }
    $counterMembers = 0
    if ($null -ne $newMembers) {
        foreach ($newMember in $newMembers) {
            try {
                $counterMembers++
                # Write-Host "Adding member $($counterMembers) of $($members.count)"
                Add-ADGroupMember -Identity $newGroupObject -Members $newMember -ErrorAction SilentlyContinue
            }
            catch {
                $a = @{
                    CommandError   = $_
                    GroupNameError = $newGroupObject.Name
                    ProblemMember  = $newMember.SamAccountName
                }
            }
        }
    }
} 
if ($errorsCreatingGroups.Count -ne '0') {
    Write-Host "Errors creating groups are $($errorsCreatingGroups)"
}
# $groupsCreated
if ($groupsNotCreated.Count -ne '0') {
    Write-Host "Groups not created are $($groupsNotCreated)"
}
if ($errorsMembers.Count -ne '0') {
    Write-Host "Errors members are $($errorsMembers)"
}