$allApex = Import-Csv c:\temp\allApex.csv
$allSanne = Import-Csv c:\temp\allSanne.csv

$apexAliases = $allApex.Alias
$ArrayList = [System.Collections.ArrayList]::new()

$matchByDisplayNameAndDisplayName = @()
$matchByUPNAndUPN = @()
$matchByAliasAndAlias = @()
$matchBySMTPAndSMTP = @()

$matchByNamesAndAlias
$matchByNamesAndSMTP

$matchByAliasAndDisplayName

$matchByAliasAndSMTP

$matchBySMTPAndDisplayName
$matchBySMTPAndAlias


# Check by firstname.lastname comparing to displayName
Measure-Command {
    foreach ($sBox in $allSanne) {
        $sDisplayName = $sBox.DisplayName
        $sAlias = $sBox.Alias
        $sUPN = ($sBox.UserPrincipalName -split '@')[0]
        $sSMTP = ($sBox.PrimarySmtpAddress -split '@')[0] 
        $firstName = ($sBox.DisplayName -split " ")[0]
        $lastName = ($sBox.DisplayName -split " ")[-1]
        $toBeAlias = $firstName + '.' + $lastName
        foreach ($aBox in $allApex) {
            $aUPN = ($aBox.UserPrincipalName -split '@')[0]
            $aSMTP = ($aBox.PrimarySmtpAddress -split '@')[0]
            if ($sDisplayName -eq $aBox.DisplayName) {
                $dNameHash = [pscustomobject]@{
                    SanneMailbox = $sBox
                    ApexMailbox  = $aBox
                }
                $matchByDisplayNameAndDisplayName += $dNameHash
            }
            if ($sAlias -eq $aBox.Alias) {
                $aliasHash = [pscustomobject]@{
                    SanneMailbox = $sBox
                    ApexMailbox = $aBox
                }
                $matchByAliasAndAlias += $aliasHash
            }
            if ($sUPN -eq $aUPN) {
                $UPNHash = [pscustomobject]@{
                    SanneMailbox = $sBox
                    ApexMailbox = $aBox
                }
                $matchByUPNAndUPN += $UPNHash
            }
            if ($sSMTP -eq $aSMTP) {
                $SMTPHash = [pscustomobject]@{
                    SanneMailbox = $sBox
                    ApexMailbox = $aBox
                }
                $matchBySMTPAndSMTP += $SMTPHash
            }
        }

    }
}
# Check by firstname.lastname comparing to alias

# Check by firstname.lastname comparing to SMTP



# Check by alias


# Check by SMTP