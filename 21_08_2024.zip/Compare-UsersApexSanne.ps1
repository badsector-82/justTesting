$allUsersSanne = Import-Csv C:\test\allUsersSanne.csv 
$allUsersApex = Get-AdUser -Filter { enabled -eq $true } -Server apexgroup.cloud

[System.Collections.ArrayList]$duplicates = @()

foreach ($sUser in $allUsersSanne) {
    $samAccountNameSanne = $sUser.samaccountname
    foreach ($aUser in $allUsersApex) {
        $samAccountNameApex = $aUser.samAccountName   
        if ($samAccountNameApex -eq $samAccountNameSanne) {
            [void]$duplicates.Add($sUser)
        }
    }
}



foreach ($user in $duplicates.samAccountName) {
    if (!(Get-ADUser $user -Server apexgroup.cloud)) {
        Write-Host "No such user"
    }
}