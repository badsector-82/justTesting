# This AuthenticateWithSecret is a slightly modified version of the method 
# described by https://adamtheautomator.com/powershell-graph-api/
$AppId = "204c841c-08c7-4920-b77a-0a3ff9c6f44c"
$TenantName = "1036b7ff-423d-4ac2-a4be-0a3650b186f9"
$AppSecret = "rLg8Q~Ay7r3m_dc.83i6RGBtvpPmC1v2wBfYEayG"

# $MailboxName = "Svc_CLOUD_Maitstream.firstlightuat@apexgroup.dev"
$MailboxName = "Maitstream.firstlightuat@apexgroup.dev"
$MailboxFolderName = "Inbox"

function Get-AccessToken
{
    param(
        [string] $AppId,
        [string] $TenantName,
        [string] $AppSecret)

    $Scope = "https://graph.microsoft.com/.default"
    $Url = "https://login.microsoftonline.com/$TenantName/oauth2/v2.0/token"

    # Add System.Web for urlencode
    Add-Type -AssemblyName System.Web

    # Create body
    $Body = @{
        client_id = $AppId
        client_secret = $AppSecret
        scope = $Scope
        grant_type = 'client_credentials'
    }

    # Splat the parameters for Invoke-Restmethod for cleaner code
    $PostSplat = @{
        ContentType = 'application/x-www-form-urlencoded'
        Method = 'POST'
        # Create string by joining bodylist with '&'
        Body = $Body
        Uri = $Url
    }

    # Request the token!
    $Request = Invoke-RestMethod @PostSplat
    return $Request
}


# This method builds a  header object that can be passed
# in with each request to the Graph REST API, for authentication
# purposes
function Get-Header
{
    param($theRequest)

    $tokenType = $theRequest.token_type
    $accessToken = $theRequest.access_token

    # Create header
    $theHeader = @{
        Authorization = "$($tokenType) $($accessToken)"
    }
    return $theHeader
}


# This method gets an object containing the email folders from
# a mailbox specified by its UserPrincipalName - which is typically
# the email address of the user concerned.  By default it will return
# the first 200 folders it finds, but you can specify however many
# that you wish to return using the $numberOfFoldersToGet parameter.
function Get-Folders
{
    param(
        $Credential,
        [string] $UserPrincipalName,
        [int]$numberOfFoldersToGet=200)

    $Header = Get-Header -theRequest $Credential
    $restUrl = "https://graph.microsoft.com/v1.0/users/$userPrincipalName/mailFolders/?`$top=$numberOfFoldersToGet"
    $folderResult = Invoke-RestMethod -Uri $restUrl -Headers $Header -Method Get -ContentType "application/json" 
    return $folderResult
}


# This is a little helper function to get the specific folder object
# from an array of folder objects.  You specify the folder that you 
# want in the array based o its displayName using the $folderNameToFind
# parameter.
function Get-FolderFromListOfFolders
{
    param($listOfFolders,
          $folderNameToFind)

    $specificFolder = ""

    # Yeah, yeah, I know - we're doing this the brute-force way - just 
    # looping through all the folders until we find the one we want.  
    # Unless you have an insane number of folders, this shouldn't take 
    # *that* long, but this loop could be re-written to use a nicer search
    # if it's really that big a problem.

    foreach($fdr in $allFolders)
    {
        $thisFolderName = $fdr.displayName
        if($thisFolderName -eq $folderNameToFind)
        {
            $specificFolder = $fdr
            break
        }
    }
    return $specificFolder
}


# This function allows you to retrieve an object describing a specific
# mail folder in an o365 Outlook, which you can specify by name.  It allows
# you to access any folder by name - not just the common ones.
function Get-SpecificFolder
{
    param(
        $Credential,
        [string] $UserPrincipalName,
        [string] $folderName)

    $allTheFolders = Get-Folders -Credential $Credential -UserPrincipalName $UserPrincipalName
    $allFolders = $allTheFolders.value
    $specificFolder = Get-FolderFromListOfFolders -listOfFolders $allFolders -folderNameToFind $folderName
    $folderId = $specificFolder.id

    $Header = Get-Header -theRequest $Credential
    $theRestQuery = "https://graph.microsoft.com/v1.0/users/$UserPrincipalName/mailFolders/$folderId"
    $folderResult = Invoke-RestMethod -Uri $theRestQuery -Headers $Header -Method Get -ContentType "application/json" 
    return $folderResult
}


# This function returns an object containing all the emails in a given 
# Mail folder in Outlook in o365
function GetEmails
{
    param(
        $Credential,
        [string] $UserPrincipalName,
        [string] $folderId)

    $Header = Get-Header -theRequest $Credential
    $restUrl = "https://graph.microsoft.com/v1.0/users/$UserPrincipalName/mailFolders/$folderId/messages"
    $emailResult = Invoke-RestMethod -Uri $restUrl -Headers $Header -Method Get -ContentType "application/json"
    return $emailResult
}

$Credential = Get-AccessToken -AppId $AppID -TenantName $TenantName -AppSecret $AppSecret


Get-SpecificFolder -Credential $Credential -UserPrincipalName $MailboxName -folderName $MailboxFolderName