$allContacts = Get-ADObject -Filter "ObjectClass -eq 'Contact'" -Server apexgroup.cloud -Properties *

[System.Collections.ArrayList]$SanneContacts = @()

$counter = 0
foreach ($contact in $allContacts) {
    $counter++
    if ($counter % 100 -eq 0) {
        Write-Host "Processing contact number $($counter)"
    }    
    if ($contact.mail -like '*sanne*') {
        [void]$SanneContacts.Add($contact)
    }
}