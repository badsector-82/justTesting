$server = "VMADS005.APEXGROUP.dev"
$sourceOU = "OU=Application Security Groups,OU=Citrix Permissions,DC=APEXGROUP,DC=DEV"
$targetOU = "OU=Application Security Groups,OU=Windows365 Permissions,DC=APEXGROUP,DC=DEV"
$sourceGroups = Get-ADGroup -Filter * -SearchBase $sourceOU -Server $server -Properties description

$count = 0
$membersWhoAreGroups3 = @()

while ($groupsAsMembers -eq $true) {

}
$creds = Get-Credential
foreach ($group in $sourceGroups) {
    $count++
    if ($count % 10 -eq 0) {
        Write-Host "Processing group number $($count) of $($sourceGroups.count)" -ForegroundColor Green
        Start-Sleep -Milliseconds 200
    }
    $sourceGroupName = $group.Name
    $newGroupName = $sourceGroupName -replace "CTX", "W365"
    $description = $group.description
    New-ADGroup -Name $newGroupName -Server $server -Path $targetOU -GroupCategory Security -GroupScope Global -Description $description -Credential $creds
}

foreach ($group in $sourceGroups) {
    $count++
    if ($count % 10 -eq 0) {
        Write-Host "Processing group number $($count) of $($sourceGroups.count)" -ForegroundColor Green
    }
    $sourceGroupName = $group.Name
    $newGroupName = $sourceGroupName -replace "CTX", "W365"
    $newGroupObject = Get-ADGroup -Filter { name -eq $newGroupName } -Properties member -Server $server -ErrorAction SilentlyContinue
    $members = $newGroupObject | select -ExpandProperty member

    foreach ($member in $members) {
        $a = Get-ADObject $member -Server $server
        if ($a.objectClass -ne 'user') {
            $b = [pscustomobject] @{
                GroupName   = $newGroupName
                MemberGroup = $a.Name
            }
            $membersWhoAreGroups3 += $b
        }
    }
}

$progress = 0
foreach ($object in $membersWhoAreGroups3) {
    $progress++
    Write-Host "processing group $($progress) from $($membersWhoAreGroups3.Count)" -ForegroundColor Green
    Start-Sleep -Milliseconds 300
    $group = $object.GroupName
    $memGroup = $object.MemberGroup
    $nestedGroupMembers = Get-ADGroup $memGroup -Properties member -Server $server | select -ExpandProperty member
    $memCounter = 0
    foreach ($member in $nestedGroupMembers) {
        $memCounter++
        Write-Host "Adding member $($member) to group $($group) - $($memCounter) from $($nestedGroupMembers.Count)"
        Add-ADGroupMember -Identity $group -Members $member -Server $server
        if ($memCounter -eq $nestedGroupMembers.Count) {
            Write-Host "Last member for group" -ForegroundColor Green
            $memCounter = 0
        }
    }
}
