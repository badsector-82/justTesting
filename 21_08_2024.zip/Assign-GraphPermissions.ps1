# Connect to Microsoft Graph
Connect-MgGraph -Scopes "Application.Read.All", "AppRoleAssignment.ReadWrite.All,RoleManagement.ReadWrite.Directory"
 
# You will be prompted for the Name of you Managed Identity
$spName = "aaacc-prod-eunorth-001"
$spID = (Get-MgBetaServicePrincipal -Filter "displayName eq '$spName'").id
 
# Adding Microsoft Graph permissions
$graphApp = Get-MgBetaServicePrincipal -Filter "AppId eq '00000003-0000-0000-c000-000000000000'"
 
# Add the required Graph scopes
$graphScopes = @(
  "User.Read.All"
  "Mail.Send"
  "Mail.ReadWrite"
)
 
ForEach ($scope in $graphScopes) {
  $appRole = $graphApp.AppRoles | Where-Object { $_.Value -eq $scope }
  if ($null -eq $appRole) { Write-Warning "Unable to find App Role for scope $scope"; continue; }
  # Check if permissions isn't already assigned
  $assignedAppRole = Get-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $spID | Where-Object { $_.AppRoleId -eq $appRole.Id -and $_.ResourceDisplayName -eq "Microsoft Graph" }
  if ($null -eq $assignedAppRole) {
    New-MgServicePrincipalAppRoleAssignment -PrincipalId $spID -ServicePrincipalId $spID -ResourceId $graphApp.Id -AppRoleId $appRole.Id
  }
  else {
    Write-Host "Scope $scope already assigned"
  }
}
#Add Office 365 Exchange Online Permissions for the App Registration
$ExoApp = Get-MgServicePrincipal -Filter "AppId eq '00000002-0000-0ff1-ce00-000000000000'"
$AppPermission = $ExoApp.AppRoles | Where-Object { $_.DisplayName -eq "Manage Exchange As Application" }
$AppRoleAssignment = @{
  "PrincipalId" = $spID
  "ResourceId"  = $ExoApp.Id
  "AppRoleId"   = $AppPermission.Id
}
New-MgServicePrincipalAppRoleAssignment -ServicePrincipalId $spID -BodyParameter $AppRoleAssignment