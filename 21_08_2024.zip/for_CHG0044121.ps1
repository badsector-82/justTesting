Connect-AzureAD
  Get-AzureADServicePrincipal -SearchString aaacc
  Get-AzureADServicePrincipal -SearchString disabled
  $sp = Get-AzureADServicePrincipal -SearchString disabled
  $sp
  New-ServicePrincipal -AppId $sp.AppId -ServiceId $sp.ObjectId -DisplayName "DisabledAccountsTestSP"
  New-ManagementScope -Name "DisabledAccountsSigninReports" -RecipientRestrictionFilter "alias -eq 'DisabledAccountsSigninReports'"
  $spExO = Get-ServicePrincipal | ? {$_.objectID -eq '74b3ed0d-8f29-48fe-bd44-91817ea7d908'}
  $spExO
  New-ManagementRoleAssignment -App $spExO.AppId -CustomResourceScope "DisabledAccountsSigninReports"
  Get-ManagementRole | where {$_.Name -like "Application*"}
  New-ManagementRoleAssignment -App $spExO.AppId -CustomResourceScope "DisabledAccountsSigninReports" -Role "Application Mail.Send"
  New-ManagementRoleAssignment -App $spExO.AppId -CustomResourceScope "DisabledAccountsSigninReports" -Role "Application EWS.AccessAsApp"
  Test-ServicePrincipalAuthorization -Identity $spExO -Resource martin.gospodinov@apexgroup.com