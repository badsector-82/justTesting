$leavers = Get-ADUser -Server apexgroup.cloud -Filter { enabled -eq $false } -Properties * | ? { $_.Name -like "*x-emp*" }
$leaversLastYear = $leavers | ? { $_.whenChanged -gt ((Get-Date).AddYears(-1)) }

$testDCs = Get-ADDomainController -Server apexgroup.cloud -Filter *
$DCs = @()
foreach ($testDc in $testDCs) {
    if (Test-Connection -ComputerName $testDC.HostName -Count 2) {
        $DCs += $testDC
    }
}
$realDCs = $DCs[0..6]

$report = New-Object System.Collections.ArrayList
$errors = @()
Measure-Command {
    foreach ($user in $leaversLastYear) {
        $realDate = 0
        foreach ($DC in $realDCs) {
            $server = $dc.HostName
            try {
            $tempUser = Get-ADUser -Identity $user -Server $server -ErrorAction Stop -Properties LastLogonDate
            }
            catch {
                $errors += $_
            }
            $LogonDate = $tempUser.LastLogonDate
            if ($LogonDate -gt $realDate) {
                $realDate = $LogonDate
            }
        }
        $uHash = [PSCustomObject]@{
            Name       = $user.name
            LastChange = $user.whenChanged
            LastAccessApprox = [DateTime]::FromFileTime($user.LastLogonTimestamp).ToString("yyyy-MM-dd HH:mm:ss")
            LastAccess = $realDate
        }
        [void]$report.Add($uHash)
    }
}

$deleted = Get-ADObject -Server apexgroup.cloud -Filter {Name -like "*x-emp*"} -IncludeDeletedObjects -Properties *
$deletedUsers = $deleted | ? {$_.deleted -eq $true -and $_.objectClass -eq 'user' }

$deletedUsersReport = New-Object System.Collections.ArrayList
foreach ($object in $deletedUsers) {
    $oHash = [PSCustomObject]@{
        Name = ($object.Name -split "del")[0]
        LastChange = $object.whenChanged
        LastAccessApprox = [DateTime]::FromFileTime($object.LastLogonTimestamp).ToString("yyyy-MM-dd HH:mm:ss")
    }
    [void]$deletedUsersReport.Add($oHash)
}
$deletedUsersReport | Export-Csv c:\test\deletedUsersReport.csv -NoTypeInformation -Encoding UTF8 -Delimiter ";"