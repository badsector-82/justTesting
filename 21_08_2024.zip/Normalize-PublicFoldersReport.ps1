$csv = Import-Csv C:\test\publicFoldersStats.csv

$newCSV = @()

foreach ($line in $csv) {
    $creationTime = $line.CreationTime
    $creationDate = [datetime]::ParseExact($creationTime,'dd/MM/yyyy HH:mm:ss',$null)
    $shortCreationDate = $creationDate.ToShortDateString()

    $lastModificationTime = $line.lastModificationTime
    $lastModificationDate = [datetime]::ParseExact($lastModificationTime,'dd/MM/yyyy HH:mm:ss',$null)
    $shortLastModificationDate = $lastModificationDate.ToShortDateString()

    $size = $line.TotalItemSize
    $splitSize = $size -split ' '
    $sizeOriginal = $splitSize[2].TrimStart('(')
    $sizeOriginal = $sizeOriginal.Replace(',','')
    $sizeInGB = $sizeOriginal/1GB

    $table = [PSCustomObject]@{
        Name = $line.Name
        MailEnabled = $line.MailEnabled
        CreationTime = $shortCreationDate
        FolderPath = $line.FolderPath
        LastModificationTime = $shortLastModificationDate
        TotalItemSize = $sizeInGB
    }
    $newCSV += $table


}