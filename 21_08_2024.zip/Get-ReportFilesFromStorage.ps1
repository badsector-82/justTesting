Connect-AzAccount -Subscription 'microsoft azure' -Identity

$stAccount = Get-AzStorageAccount -ResourceGroupName 'FundrockBusinessSupportReports' -Name 'sometestaccounthere1'
$storageContext = New-AzStorageContext -StorageAccountName $stAccount.StorageAccountName -UseConnectedAccount

$container = (Get-AzStorageContainer -Name 'reports' -Context $storageContext).CloudBlobContainer

$encoding = [System.Text.Encoding]::UTF8
Remove-AzStorageBlob -Container 'reports' -Blob 'Internal.csv' -Context $storageContext
Remove-AzStorageBlob -Container 'reports' -Blob 'External.csv' -Context $storageContext